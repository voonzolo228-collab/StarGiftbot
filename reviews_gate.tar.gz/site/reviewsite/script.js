// Telegram Web App API
let tg = window.Telegram.WebApp;
tg.expand();

// Получаем данные пользователя из Telegram
const telegramUser = tg.initDataUnsafe.user;
const username = telegramUser ? telegramUser.username || telegramUser.first_name : 'Guest';

// Подписанная строка: только по ней сервер понимает, кто пришёл.
// В браузере без Telegram она пустая — форма и свои отзывы будут недоступны.
const initData = tg.initData || '';

// Право на отзыв выдаёт сервер, здесь только рисуем результат.
let profile = { authorized: false, canReview: false, deals: 0, required: 2 };

function authHeaders(extra) {
    return Object.assign({ 'X-Telegram-Init-Data': initData }, extra || {});
}

// Переводы
const translations = {
    ru: {
        reviewTitle: 'Как оставить отзыв?',
        step1: '1. Выберите оценку (1-5)',
        step2: '2. Выберите подарок который вы продали/купили',
        step3: '3. Напишите мини коментарий',
        ratingLabel: 'Оценка',
        nicknameLabel: 'Ник',
        giftLabel: 'Подарок',
        giftPlaceholder: 'Выбрать подарок',
        textLabel: 'Текст',
        textPlaceholder: 'как прошла сделка в боте',
        submitButton: 'Опубликовать',
        allReviews: 'Все отзывы',
        reviewsShown: 'Вам показаны',
        reviewsOf: 'отзывов из',
        charLimit: '/ максимум 50 символов',
        reviews: 'отзывов',
        gateNeedDeals: 'Отзыв можно оставить после {required} завершённых сделок. У вас сейчас: {deals}.',
        gateNoAuth: 'Откройте страницу через бота, чтобы оставить отзыв.',
        gateError: 'Не удалось проверить ваши сделки. Попробуйте позже.'
    },
    en: {
        reviewTitle: 'How to leave a review?',
        step1: '1. Select rating (1-5)',
        step2: '2. Select the gift you sold/bought',
        step3: '3. Write a mini comment',
        ratingLabel: 'Rating',
        nicknameLabel: 'Nickname',
        giftLabel: 'Gift',
        giftPlaceholder: 'Select gift',
        textLabel: 'Text',
        textPlaceholder: 'how the deal went',
        submitButton: 'Submit',
        allReviews: 'All reviews',
        reviewsShown: 'Showing',
        reviewsOf: 'reviews out of',
        charLimit: '/ max 50 characters',
        reviews: 'reviews',
        gateNeedDeals: 'You can leave a review after {required} completed deals. You have {deals}.',
        gateNoAuth: 'Open this page from the bot to leave a review.',
        gateError: 'Could not check your deals. Please try again later.'
    },
    zh: {
        reviewTitle: '如何留下评论？',
        step1: '1. 选择评分 (1-5)',
        step2: '2. 选择您出售/购买的礼物',
        step3: '3. 写一条简短评论',
        ratingLabel: '评分',
        nicknameLabel: '昵称',
        giftLabel: '礼物',
        giftPlaceholder: '选择礼物',
        textLabel: '文本',
        textPlaceholder: '交易进展如何',
        submitButton: '提交',
        allReviews: '所有评论',
        reviewsShown: '显示',
        reviewsOf: '条评论，共',
        charLimit: '/ 最多50个字符',
        reviews: '条评论',
        gateNeedDeals: '完成 {required} 笔交易后即可留下评论。您目前有 {deals} 笔。',
        gateNoAuth: '请通过机器人打开此页面以留下评论。',
        gateError: '无法核对您的交易，请稍后再试。'
    },
    ar: {
        reviewTitle: 'كيفية ترك تقييم؟',
        step1: '1. اختر التقييم (1-5)',
        step2: '2. اختر الهدية التي بعتها/اشتريتها',
        step3: '3. اكتب تعليقًا صغيرًا',
        ratingLabel: 'التقييم',
        nicknameLabel: 'الاسم',
        giftLabel: 'الهدية',
        giftPlaceholder: 'اختر الهدية',
        textLabel: 'النص',
        textPlaceholder: 'كيف سارت الصفقة',
        submitButton: 'نشر',
        allReviews: 'جميع التقييمات',
        reviewsShown: 'يتم عرض',
        reviewsOf: 'تقييمًا من',
        charLimit: '/ بحد أقصى 50 حرفًا',
        reviews: 'تقييمات',
        gateNeedDeals: 'يمكنك ترك تقييم بعد {required} صفقات مكتملة. لديك الآن {deals}.',
        gateNoAuth: 'افتح هذه الصفحة من خلال البوت لترك تقييم.',
        gateError: 'تعذر التحقق من صفقاتك. حاول لاحقًا.'
    }
};

let currentLang = 'ru';

function updateLanguage(lang) {
    currentLang = lang;
    const t = translations[lang];
    
    // Обновляем направление текста для арабского
    if (lang === 'ar') {
        document.body.setAttribute('dir', 'rtl');
        document.documentElement.setAttribute('lang', 'ar');
    } else {
        document.body.setAttribute('dir', 'ltr');
        document.documentElement.setAttribute('lang', lang);
    }
    
    // Обновляем текст на странице
    document.querySelector('.form-title').textContent = t.reviewTitle;
    document.querySelectorAll('.form-instructions p')[0].textContent = t.step1;
    document.querySelectorAll('.form-instructions p')[1].textContent = t.step2;
    document.querySelectorAll('.form-instructions p')[2].textContent = t.step3;
    
    document.querySelectorAll('.form-group label')[0].textContent = t.ratingLabel;
    document.querySelectorAll('.form-group label')[1].textContent = t.nicknameLabel;
    document.querySelectorAll('.form-group label')[2].textContent = t.giftLabel;
    document.querySelectorAll('.form-group label')[3].textContent = t.textLabel;
    
    document.getElementById('gift-select-text').textContent = t.giftPlaceholder;
    document.getElementById('text-input').placeholder = t.textPlaceholder;
    document.querySelector('.submit-button').textContent = t.submitButton;
    
    document.querySelector('.reviews-header h3').textContent = t.allReviews;
    
    // Обновляем rating-total с реальным количеством
    const totalCount = document.getElementById('total-reviews-count').textContent;
    document.querySelector('.rating-total').innerHTML = `<span id="total-reviews-count">${totalCount}</span> ${t.reviews}`;
    
    // Обновляем футер
    const footerText = document.querySelector('.reviews-footer p');
    const shownCount = document.getElementById('shown-reviews-count').textContent;
    const totalCountFooter = document.getElementById('footer-total-count').textContent;
    footerText.innerHTML = `${t.reviewsShown} <span id="shown-reviews-count">${shownCount}</span> ${t.reviewsOf} <span id="footer-total-count">${totalCountFooter}</span>`;
    
    // Обновляем счётчик символов
    const charCounter = document.querySelector('.char-counter');
    const currentCount = document.getElementById('char-count').textContent;
    charCounter.innerHTML = `<span id="char-count">${currentCount}</span> ${t.charLimit}`;

    applyReviewGate();
}

// Пустая строка = отзыв оставлять можно.
function gateMessage() {
    const t = translations[currentLang] || translations.ru;
    if (profile.error) return t.gateError;
    if (!profile.authorized) return t.gateNoAuth;
    if (!profile.canReview) {
        return t.gateNeedDeals
            .replace('{required}', profile.required)
            .replace('{deals}', profile.deals);
    }
    return '';
}

function applyReviewGate() {
    const notice = document.getElementById('review-gate');
    const button = document.querySelector('.submit-button');
    const form = document.querySelector('.review-form');
    if (!notice || !button || !form) return;

    const message = gateMessage();
    notice.textContent = message;
    notice.hidden = !message;
    button.disabled = Boolean(message);
    form.classList.toggle('review-form--locked', Boolean(message));
}

async function loadProfile() {
    const defaults = { authorized: false, canReview: false, deals: 0, required: 2 };
    try {
        const response = await fetch('/api/me', { headers: authHeaders() });
        profile = Object.assign({}, defaults, await response.json());
    } catch (error) {
        console.error('Failed to load profile:', error);
        profile = Object.assign({}, defaults, { error: 'network' });
    }
    applyReviewGate();
}

// Scroll animations
function observeElements() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry, index) => {
            if (entry.isIntersecting) {
                // Добавляем задержку для каскадного эффекта
                setTimeout(() => {
                    entry.target.classList.add('show');
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }, index * 50);
            }
        });
    }, {
        threshold: 0.05,
        rootMargin: '0px 0px -30px 0px'
    });

    // Наблюдаем за элементами
    document.querySelectorAll('.rating-statistics, .review-form, .review-item, .reviews-footer').forEach(el => {
        observer.observe(el);
    });
}

// Total reviews count - REAL COUNT (starts at 100, matches reviewsData length)
let totalReviewsCount = 100; // Реальное количество отзывов в reviewsData

// Gift items list
const giftItems = [
    "Jack-in-the-Box", "Mighty Arm", "B-Day Candle", "Flying Broom", "Star Notepad",
    "Moon Pendant", "Ginger Cookie", "Witch Hat", "Joyful Bundle", "Restless Jar",
    "Hanging Star", "Love Candle", "Happy Brownie", "Eternal Candle", "Holiday Drink",
    "Lush Bouquet", "Skull Flower", "Ion Gem", "Tama Gadget", "Artisan Brick",
    "Perfume Bottle", "Swag Bag", "Mini Oscar", "Genie Lamp", "Scared Cat",
    "Hex Pot", "Voodoo Doll", "Neko Helmet", "Snoop Dogg", "Sleigh Bell",
    "Snoop Cigar", "Spiced Wine", "Desk Calendar", "Lol Pop", "Light Sword",
    "Cookie Heart", "Lunar Snake", "Party Sparkler", "Crystal Ball", "Low Rider",
    "Clover Pin", "Bunny Muffin", "Faith Amulet", "Big Year", "Durov's Cap",
    "Plush Pepe", "Cupid Charm", "Gem Signet", "Heroic Helmet", "Fresh Socks",
    "Swiss Watch", "Valentine Box", "Spy Agaric", "Jolly Chimp", "Spring Basket",
    "Electric Skull", "Santa Hat", "Record Player", "Input Key", "Hypno Lollipop",
    "Snow Globe", "Stellar Rocket", "Evil Eye", "Sharp Tongue", "Winter Wreath",
    "Ionic Dryer", "Xmas Stocking", "Sakura Flower", "Love Potion", "Kissed Frog",
    "Snake Box", "Jingle Bells", "Astral Shard", "Top Hat", "Diamond Ring",
    "Magic Potion", "Whip Cupcake", "Mad Pumpkin", "Easter Egg", "Pet Snake",
    "Westside Sign", "Loot Bag", "Trapped Heart", "Ice Cream", "Berry Box",
    "Candy Cane", "Bonded Ring", "Vintage Cigar", "Heart Locket", "Jelly Bunny",
    "Jester Hat", "Precious Peach", "Instant Ramen", "Toy Bear", "Nail Bracelet",
    "Snow Mittens", "Eternal Rose", "Bow Tie", "Mousse Cake", "Sky Stilettos",
    "Signet Ring", "Homemade Cake"
];

// Reviews data with dates for sorting
const reviewsData = [
    { username: 'nemki', gift: 'Switch Watchs', text: 'норм продал', date: '2026-07-09', rating: 5 },
    { username: 'simple', gift: 'Heroic Helmet', text: 'продаю и покупаю тут, escrow для телеги подарков', date: '2026-07-03', rating: 5 },
    { username: 'soft_demon', gift: 'Trapped Heart', text: 'забрал Trapped Heart после оплаты. бот не отпустил пока не заплатил', date: '2026-07-03', rating: 5 },
    { username: 'nemo', gift: 'Plush Pepe', text: 'продал пепу через бота, пока покупатель платил гарант держал, деньги пришли без косяков', date: '2026-06-30', rating: 5, hasHeart: true },
    { username: 'sutpa', gift: 'Durov\'s Cap', text: 'купил кепку, продавец закинул в бота и я спокойно оплатил. гарант норм', date: '2026-06-30', rating: 5 },
    { username: 'высоцкий', gift: 'Loot Bag', text: 'мешок брал, бот держал сделку пока переводил. в лс так бы не рискнул', date: '2026-06-29', rating: 5 },
    { username: 'vebber', gift: 'Swiss Watch', text: 'часы купил, гарант отработал но минут 20 ждал пока продавец закинет подарок', date: '2026-06-29', rating: 4 },
    { username: 'ivan_zolo', gift: 'Scared Cat', text: 'кота продал, покупатель забрал из бота и мне упали бабки. чисто', date: '2026-06-28', rating: 5 },
    { username: 'сын_собаки', gift: 'Homemade Cake', text: 'маме тортик брал, гарант держал пока оплачивал. удобно что не кидают', date: '2026-06-28', rating: 5 },
    { username: 'мама_мелва', gift: 'Magic Potion', text: 'зелье продала через бота. выплата пришла после того как покупатель забрал. меня советовал', date: '2026-06-27', rating: 4 },
    { username: 'rivultion', gift: 'Electric Skull', text: 'череп купил, продавец сначала в бота, потом я оплатил и забрал. как маркетплейс только для подарков', date: '2026-06-27', rating: 5 },
    { username: 'east_ace', gift: 'Genie Lamp', text: 'продаю и покупаю тут. ескоу для телеги подарков', date: '2026-06-26', rating: 5 },
    { username: 'black_eye', gift: 'Spiced Wine', text: 'сделка с spiced wine закрылась. гарант норм, коммуникация слабая', date: '2026-06-25', rating: 4 },
    { username: 'nissim', gift: 'Witch Hat', text: 'сделка чистая. ждал дольше чем хотелось', date: '2026-06-23', rating: 4 },
    { username: 'southsniper', gift: 'Jester Hat', text: 'гарант сработал, но минут 20 ждал ответа', date: '2026-06-22', rating: 4 },
    { username: 'леха', gift: 'Jelly Bunny', text: 'jelly bunny слал. гарант провёл. бабки на месте', date: '2026-06-20', rating: 5 },
    { username: 'Hobbit', gift: 'Witch Hat', text: 'гарант сработал, но минут 20 ждал ответа', date: '2026-06-20', rating: 4 },
    { username: 'bigclutch', gift: 'Party Sparkler', text: 'удобнее чем вручную договариваться с незнакомцем', date: '2026-06-18', rating: 5 },
    { username: 'icefox', gift: 'Spiced Wine', text: 'купил Spiced Wine, гарант ок но продавец долго кидал в бота', date: '2026-06-18', rating: 4 },
    { username: 'darksoul', gift: 'Love Potion', text: 'продал love potion, выплата пришла, минут 15 ждал покупателя', date: '2026-06-18', rating: 4 },
    { username: 'дровдер', gift: 'Electric Skull', text: 'сделка с Electric Skull закрылась. гарант норм, коммуникация слабая', date: '2026-06-17', rating: 4 },
    { username: 'gold_ace', gift: 'Jester Hat', text: 'гарант сработал, но минут 20 ждал ответа', date: '2026-06-16', rating: 4 },
    { username: 'sun_man', gift: 'Ginger Cookie', text: 'ginger cookie продал через гарант, не кидали ни меня ни покупателя', date: '2026-06-15', rating: 5 },
    { username: 'peekdragon', gift: 'Restless Jar', text: 'покупал restless jar, продавец кинул в escrow бота и я спокойно оплатил', date: '2026-06-12', rating: 5 },
    { username: 'swap_ton', gift: 'Magic Potion', text: 'выставил Magic Potion, бот держал пока покупатель платил', date: '2026-06-11', rating: 5 },
    { username: 'smokeman', gift: 'Perfume Bottle', text: 'взял Perfume Bottle, сначала подарок в боте потом платёж, норм схема', date: '2026-06-10', rating: 5 },
    { username: 'markiplier', gift: 'Spy Agaric', text: 'минут 5-10 и готово, гарант всё провёл', date: '2026-06-10', rating: 5 },
    { username: 'flash_dragon', gift: 'Toy Bear', text: 'гарант сработал, но минут 20 ждал ответа', date: '2026-06-09', rating: 4 },
    { username: 'big russian boss', gift: 'Top Hat', text: 'бот молчал потом провёл сделку, нервы были', date: '2026-06-07', rating: 4 },
    { username: 'sneakrifler', gift: 'Jingle Bells', text: 'в целом ок, гарант держит как надо', date: '2026-06-05', rating: 4 },
    { username: 'travian', gift: 'Trapped Heart', text: 'trapped heart, бот как посредник, без нервов', date: '2026-05-15', rating: 5 },
    { username: 'cs_gaules', gift: 'Desk Calendar', text: 'продаю и покупаю тут, escrow для телеги подарков ))', date: '2026-05-14', rating: 5 },
    { username: 'chillhawk', gift: 'Durov\'s Cap', text: 'продал Durov\'s Cap, выплата пришла, минут 15 ждал покупателя', date: '2026-05-14', rating: 4 },
    { username: 'deagle_run', gift: 'Jingle Bells', text: 'как фанней только для nft подарков, зашло', date: '2026-05-13', rating: 5 },
    { username: 'drop_line', gift: 'Magic Potion', text: 'сделка чистая, подарок не пропал по дороге', date: '2026-05-13', rating: 5 },
    { username: 'blackfox', gift: 'Flying Broom', text: 'продал Flying Broom, покупатель забрал из бота и мне упали деньги', date: '2026-05-13', rating: 5 },
    { username: 'miyagi', gift: 'Cupid Charm', text: 'бот молчал потом провёл сделку, нервы были', date: '2026-05-13', rating: 4 },
    { username: 'flash_master', gift: 'Swiss Watch', text: 'не с первого клика но подарок дошёл', date: '2026-05-13', rating: 4 },
    { username: 'gold_head', gift: 'Tama Gadget', text: 'отдал Tama Gadget в бота, деньги пришли после сделки', date: '2026-05-12', rating: 5 },
    { username: 'анстипопер', gift: 'Love Candle', text: 'минут 5-10 и готово, гарант всё провёл', date: '2026-05-12', rating: 5 },
    { username: 'hotrifler', gift: 'Party Sparkler', text: 'не первый раз, гарант всегда отрабатывает', date: '2026-05-12', rating: 5 },
    { username: 'komar', gift: 'Witch Hat', text: 'удобнее чем вручную договариваться с незнакомцем', date: '2026-05-11', rating: 5 },
    { username: 'coldrifler', gift: 'Xmas Stocking', text: 'xmas stocking купил через гарант, без бота в лс не стал бы', date: '2026-05-10', rating: 5 },
    { username: 'ace_eye', gift: 'Electric Skull', text: 'сливаешь подарок, ждёшь покупателя, бот всё фиксит', date: '2026-05-10', rating: 5 },
    { username: 'sneaksoul', gift: 'Diamond Ring', text: 'брал Diamond Ring, в итоге всё ок, чуть дольше обычного', date: '2026-05-10', rating: 4 },
    { username: 'moist', gift: 'Lunar Snake', text: 'третий обмен уже, гарант не подводил', date: '2026-05-09', rating: 5 },
    { username: 'night_star', gift: 'Record Player', text: 'Record Player продал, деньги пришли, не моментально', date: '2026-05-08', rating: 4 },
    { username: 'slow_hunter', gift: 'Nail Bracelet', text: 'удобнее чем вручную договариваться с незнакомцем', date: '2026-05-08', rating: 5 },
    { username: 'moon_core', gift: 'Neko Helmet', text: 'третий обмен уже, гарант не подводил', date: '2026-05-08', rating: 5 },
    { username: 'toxic', gift: 'Neko Helmet', text: 'бот молчал потом провёл сделку, нервы были', date: '2026-05-07', rating: 4 },
    { username: 'chillclutch', gift: 'Loot Bag', text: 'сделка с Loot Bag закрылась, гарант норм, коммуникация слабая', date: '2026-05-06', rating: 4 },
    { username: 'markul', gift: 'Input Key', text: 'Input Key купил через гарант, без бота в лс не стал бы', date: '2026-05-05', rating: 5 },
    { username: 'big_zone', gift: 'Nail Bracelet', text: 'не первый раз, гарант всегда отрабатывает', date: '2026-05-05', rating: 5 },
    { username: 'darkfox', gift: 'Tama Gadget', text: 'сделка чистая, подарок не пропал по дороге', date: '2026-05-05', rating: 5 },
    { username: 'smoke_flash', gift: 'Jelly Bunny', text: 'jelly bunny продал через гарант', date: '2026-05-05', rating: 5 },
    { username: 'lil_hand', gift: 'Magic Potion', text: 'Magic Potion, бот как посредник, без нервов', date: '2026-05-02', rating: 5 },
    { username: 'west_rifler', gift: 'Cupid Charm', text: 'сделка чистая, ждал дольше чем хотелось', date: '2026-05-02', rating: 4 },
    { username: 'white_angel', gift: 'Nail Bracelet', text: 'оплатил и Nail Bracelet прилетел, гарант отработал как надо', date: '2026-05-01', rating: 5 },
    { username: 'fine_flash', gift: 'Tama Gadget', text: 'в целом ок, гарант держит как надо', date: '2026-05-01', rating: 4 },
    { username: 'edisonpts', gift: 'Perfume Bottle', text: 'продавец закинул, я оплатил, забрал, всё', date: '2026-05-01', rating: 5 },
    { username: 'storm_dog', gift: 'Signet Ring', text: 'signet ring продал без проблем, деньги пришли в бота', date: '2026-04-29', rating: 5 },
    { username: 'slysniper', gift: 'Eternal Rose', text: 'удобнее чем вручную договариваться с незнакомцем', date: '2026-04-29', rating: 5 },
    { username: 'forcedog', gift: 'Jelly Bunny', text: 'купил jelly bunny, гарант ок но продавец долго кидал в бота', date: '2026-04-29', rating: 4 },
    { username: 'steel_peek', gift: 'Signet Ring', text: 'сделка чистая, подарок не пропал по дороге лол', date: '2026-04-29', rating: 5 },
    { username: 'real_line', gift: 'Moon Pendant', text: 'бот не отпускает подарок пока не оплатишь, топ', date: '2026-04-28', rating: 5 },
    { username: 'sly_head', gift: 'Flying Broom', text: 'гарант сработал, но минут 20 ждал ответа', date: '2026-04-28', rating: 4 },
    { username: 'starflex', gift: 'Joyful Bundle', text: 'продавец закинул, я оплатил, забрал, всё', date: '2026-04-28', rating: 5 },
    { username: 'ghost_man', gift: 'Kissed Frog', text: 'оплатил и Kissed Frog прилетел, гарант отработал как надо', date: '2026-04-27', rating: 5 },
    { username: 'south_dragon', gift: 'Perfume Bottle', text: 'брал Perfume Bottle, гарант держал пока переводил, всё чётко', date: '2026-04-27', rating: 5 },
    { username: 'south', gift: 'Scared Cat', text: 'продал scared cat, выплата пришла, минут 15 ждал покупателя', date: '2026-04-27', rating: 4 },
    { username: 'ace_lurker', gift: 'Star Notepad', text: 'продаю и покупаю тут, escrow для телеги подарков', date: '2026-04-26', rating: 5 },
    { username: 'southrat', gift: 'Durov\'s Cap', text: 'Durov\'s Cap, бот как посредник, без нервов', date: '2026-04-26', rating: 5 },
    { username: 'red_mind', gift: 'Mad Pumpkin', text: 'продал Mad Pumpkin, покупатель забрал из бота и мне упали деньги', date: '2026-04-25', rating: 5 },
    { username: 'southgod', gift: 'Skull Flower', text: 'брал Skull Flower, гарант держал пока переводил, всё чётко', date: '2026-04-25', rating: 5 },
    { username: 'smoker', gift: 'Mad Pumpkin', text: 'mad pumpkin прилетел, нормально', date: '2026-04-22', rating: 4 },
    { username: 'fragman', gift: 'Moon Pendant', text: 'сливаешь подарок, ждёшь покупателя, бот всё фиксит', date: '2026-04-21', rating: 5 },
    { username: 'chillboy', gift: 'Record Player', text: 'бот не отпускает подарок пока не оплатишь, топ', date: '2026-04-21', rating: 5 },
    { username: 'frag_kid', gift: 'Love Candle', text: 'сделка с love candle закрылась, гарант норм, коммуникация слабая', date: '2026-04-20', rating: 4 },
    { username: 'wolf_head', gift: 'Holiday Drink', text: 'в целом ок, гарант держит как надо', date: '2026-04-20', rating: 4 },
    { username: 'bluerat', gift: 'Star Notepad', text: 'Star Notepad продал, деньги пришли, не моментально', date: '2026-04-20', rating: 4 },
    { username: 'kinq', gift: 'Light Sword', text: 'Light Sword продал, деньги пришли, не моментально', date: '2026-04-20', rating: 4 },
    { username: 'force_team', gift: 'Sharp Tongue', text: 'бот держит подарок пока платите, удобная тема', date: '2026-04-17', rating: 5 },
    { username: 'eco_smoke', gift: 'Love Potion', text: 'отдал Love Potion в бота, деньги пришли после сделки', date: '2026-04-17', rating: 5 },
    { username: 'lowcore', gift: 'Desk Calendar', text: 'Desk Calendar купил через гарант, без бота в лс не стал бы', date: '2026-04-16', rating: 5 },
    { username: 'clutch_team', gift: 'Spy Agaric', text: 'Spy Agaric купил через гарант, без бота в лс не стал бы', date: '2026-04-16', rating: 5 },
    { username: 'chill_support', gift: 'Plush Pepe', text: 'продавец тупил но бот сделку не потерял', date: '2026-04-16', rating: 4 },
    { username: 'redking', gift: 'Star Notepad', text: 'покупал Star Notepad, продавец кинул в escrow бота и я спокойно оплатил', date: '2026-04-16', rating: 5 },
    { username: 'ace_master', gift: 'Spiced Wine', text: 'забрал Spiced Wine после оплаты, бот не отпустил пока не заплатил', date: '2026-04-06', rating: 5 },
    { username: 'unluckyman', gift: 'Love Candle', text: 'брал Love Candle, гарант держал пока переводил, всё чётко', date: '2026-04-06', rating: 5 },
    { username: 'gold_master', gift: 'Jingle Bells', text: 'сделка с Jingle Bells закрылась, гарант норм, коммуникация слабая', date: '2026-04-05', rating: 4 },
    { username: 'wildeye', gift: 'Restless Jar', text: 'продал restless jar, покупатель забрал из бота и мне упали деньги', date: '2026-04-05', rating: 5 },
    { username: 'deagle_shot', gift: 'Input Key', text: 'как фанней только для nft подарков, зашло', date: '2026-04-05', rating: 5 },
    { username: 'low_clutch', gift: 'Genie Lamp', text: 'купил genie lamp, гарант ок но продавец долго кидал в', date: '2026-04-06', rating: 4 }
];

// Star rating functionality
document.addEventListener('DOMContentLoaded', function() {
    // Заполняем поле Ник автоматически из Telegram
    document.getElementById('nickname-input').value = username;
    document.getElementById('nickname-input').disabled = true; // Запрещаем редактирование

    loadProfile(); // включит или заблокирует форму, когда сервер посчитает сделки

    const starInputs = document.querySelectorAll('.star-input');
    let selectedRating = 0;

    starInputs.forEach((star, index) => {
        // Hover effect
        star.addEventListener('mouseenter', function() {
            highlightStars(index + 1);
        });

        // Click to select
        star.addEventListener('click', function() {
            selectedRating = index + 1;
            highlightStars(selectedRating);
        });
    });

    // Reset on mouse leave
    const starRating = document.querySelector('.star-rating');
    starRating.addEventListener('mouseleave', function() {
        highlightStars(selectedRating);
    });

    function highlightStars(count) {
        starInputs.forEach((star, index) => {
            if (index < count) {
                star.classList.add('active');
            } else {
                star.classList.remove('active');
            }
        });
    }

    // Sort reviews by date (newest first) and load
    sortAndLoadReviews(); // Вызываем async функцию
    
    // Update review counts on page load
    updateReviewCount();

    // Initialize gift dropdown
    initGiftDropdown();

    // Initialize scroll animations
    observeElements();

    // Language switcher
    document.querySelectorAll('.lang-switch__btn').forEach(btn => {
        btn.addEventListener('click', function() {
            // Убираем активный класс у всех кнопок
            document.querySelectorAll('.lang-switch__btn').forEach(b => b.classList.remove('is-active'));
            // Добавляем активный класс текущей кнопке
            this.classList.add('is-active');
            // Обновляем язык
            updateLanguage(this.dataset.lang);
        });
    });

    // Character counter for textarea
    const textInput = document.getElementById('text-input');
    const charCount = document.getElementById('char-count');
    const charCounter = document.querySelector('.char-counter');

    textInput.addEventListener('input', function() {
        const length = this.value.length;
        charCount.textContent = length;

        if (length > 50) {
            // Truncate to 50 characters
            this.value = this.value.substring(0, 50);
            charCount.textContent = 50;
        }

        if (length >= 45) {
            charCounter.classList.add('error');
            charCounter.classList.remove('success');
        } else {
            charCounter.classList.remove('error');
            if (length > 0) {
                charCounter.classList.add('success');
            } else {
                charCounter.classList.remove('success');
            }
        }
    });

    // Form submission
    const submitButton = document.querySelector('.submit-button');
    submitButton.addEventListener('click', async function(e) {
        e.preventDefault();

        // Сервер проверит это ещё раз, здесь — чтобы не гонять заведомо отказной запрос
        const blocked = gateMessage();
        if (blocked) {
            tg.showAlert(blocked);
            return;
        }

        const gift = document.getElementById('gift-input-hidden').value;
        const reviewText = document.getElementById('text-input').value;

        if (selectedRating === 0) {
            tg.showAlert('Пожалуйста, выберите оценку');
            return;
        }

        if (!gift.trim()) {
            tg.showAlert('Пожалуйста, выберите подарок');
            return;
        }

        if (!reviewText.trim()) {
            tg.showAlert('Пожалуйста, напишите текст отзыва');
            return;
        }

        if (reviewText.trim().length > 50) {
            tg.showAlert('Текст отзыва не должен превышать 50 символов');
            return;
        }

        // Ник сервер подставит сам из подписи Telegram — отсюда его не шлём
        const reviewData = {
            initData: initData,
            gift: gift,
            text: reviewText,
            rating: selectedRating
        };

        // Отправляем данные через Telegram Web App API
        try {
            // Отправляем на сервер
            const response = await fetch('/api/submit-review', {
                method: 'POST',
                headers: authHeaders({ 'Content-Type': 'application/json' }),
                body: JSON.stringify(reviewData)
            });

            if (response.ok) {
                // Показываем уведомление об успехе
                tg.showAlert('✅ Спасибо за ваш отзыв!');

                // Закрываем мини-приложение
                setTimeout(() => {
                    tg.close();
                }, 1500);
                return;
            }

            // Сделок стало меньше порога или подпись протухла — обновляем состояние формы
            if (response.status === 401 || response.status === 403 || response.status === 503) {
                await loadProfile();
                tg.showAlert(gateMessage() || '❌ Ошибка при отправке отзыва');
                return;
            }

            tg.showAlert('❌ Ошибка при отправке отзыва');
        } catch (error) {
            console.error('Error:', error);
            tg.showAlert('❌ Ошибка при отправке отзыва');
        }
    });
});

async function sortAndLoadReviews() {
    let customReviewsCount = 0;
    let customReviews = [];
    
    // Загружаем custom отзывы из txt файла
    try {
        // Сервер вернёт только отзывы этого пользователя: чужие никому не видны
        const response = await fetch('/api/get-custom-reviews', { headers: authHeaders() });
        if (response.ok) {
            const data = await response.json();
            if (data.reviews && data.reviews.length > 0) {
                customReviewsCount = data.reviews.length;
                customReviews = data.reviews;
                
                // Сортируем custom отзывы по дате (новые первыми)
                customReviews.sort((a, b) => {
                    if (!a.date) return 1;
                    if (!b.date) return -1;
                    return new Date(b.date) - new Date(a.date);
                });
                
                // Подсветка «⭐ Новый» — только на отзывах текущего пользователя.
                // Раньше её видели все на самом свежем отзыве, чужом в том числе.
                let ownMarked = false;
                customReviews.forEach(review => {
                    const isOwn = review.username === username;
                    review.isNew = isOwn;
                    // «Недавно» вместо даты — на самом свежем СВОЁМ отзыве
                    review.showRecent = isOwn && !ownMarked;
                    if (isOwn) ownMarked = true;
                });

                // Свои отзывы поднимаем над чужими, чтобы человек сразу видел свой
                customReviews.sort((a, b) => {
                    const aOwn = a.username === username ? 1 : 0;
                    const bOwn = b.username === username ? 1 : 0;
                    return bOwn - aOwn;
                });

                // unshift переворачивает порядок, поэтому идём с конца
                for (let i = customReviews.length - 1; i >= 0; i--) {
                    reviewsData.unshift(customReviews[i]);
                }
                
                console.log(`Loaded ${customReviewsCount} custom reviews`);
            }
        }
    } catch (error) {
        console.error('Failed to load custom reviews:', error);
    }
    
    // Обновляем РЕАЛЬНЫЙ счётчик отзывов (фактическое количество в массиве)
    totalReviewsCount = reviewsData.length;
    
    // Sort by date (newest first)
    reviewsData.sort((a, b) => {
        // Свой отзыв — всегда самый первый, чтобы не искать его в списке
        const aOwn = a.username === username ? 1 : 0;
        const bOwn = b.username === username ? 1 : 0;
        if (aOwn !== bOwn) return bOwn - aOwn;
        if (a.isCustom && !b.isCustom) return -1; // Custom отзывы всегда первые
        if (!a.isCustom && b.isCustom) return 1;
        return new Date(b.date) - new Date(a.date);
    });
    
    loadReviews();
    
    // Обновляем счётчики после загрузки
    updateReviewCount();
}

function loadReviews() {
    const container = document.getElementById('reviews-container');
    container.innerHTML = '';

    // Показываем ВСЕ отзывы (реальное количество)
    reviewsData.forEach((review) => {
        const reviewElement = createReviewElement(review);
        container.appendChild(reviewElement);
    });
    
    // Запускаем наблюдение за новыми элементами
    observeElements();
}

function escapeHtml(value) {
    const holder = document.createElement('div');
    holder.textContent = value == null ? '' : String(value);
    return holder.innerHTML;
}

function createReviewElement(review) {
    const reviewDiv = document.createElement('div');
    reviewDiv.className = 'review-item';

    // Проверяем, является ли это отзывом текущего пользователя
    if (review.username === username) {
        reviewDiv.classList.add('review-item--own');
    }
    
    // Добавляем класс "custom-review" (желтый фон) ТОЛЬКО для самого нового
    if (review.isNew) {
        reviewDiv.classList.add('custom-review');
    }

    const stars = generateStars(review.rating);
    const heartIcon = review.hasHeart ? '<span class="review-heart">💜</span>' : '';
    
    // Определяем дату для отображения
    let formattedDate;
    if (review.isCustom) {
        if (review.showRecent) {
            formattedDate = 'Недавно';
        } else if (review.date) {
            formattedDate = formatDate(review.date);
        } else {
            formattedDate = 'Недавно';
        }
    } else {
        formattedDate = formatDate(review.date);
    }

    // Генерируем инициалы из имени пользователя (первые 2 буквы)
    const initials = escapeHtml(review.username.substring(0, 2).toUpperCase());

    reviewDiv.innerHTML = `
        <div class="review-top">
            <div class="review-left">
                <div class="review-avatar">
                    ${initials}
                </div>
                <div class="review-user-info">
                    <div class="review-username">
                        ${escapeHtml(review.username)}
                        ${heartIcon}
                    </div>
                    <a href="#" class="review-gift">${escapeHtml(review.gift)}</a>
                </div>
            </div>
            <div class="review-stars">${stars}</div>
        </div>
        <p class="review-text">${escapeHtml(review.text)}</p>
        <span class="review-date">${escapeHtml(formattedDate)}</span>
    `;

    return reviewDiv;
}

function generateStars(rating) {
    let stars = '';
    for (let i = 1; i <= 5; i++) {
        if (i <= rating) {
            stars += '<span class="review-star">★</span>';
        } else {
            stars += '<span class="review-star empty">☆</span>';
        }
    }
    return stars;
}

function formatDate(dateStr) {
    const months = ['янв.', 'фев.', 'мар.', 'апр.', 'мая', 'июн.', 'июл.', 'авг.', 'сен.', 'окт.', 'ноя.', 'дек.'];
    const date = new Date(dateStr);
    const day = date.getDate();
    const month = months[date.getMonth()];
    const year = date.getFullYear();
    return `${day} ${month} ${year} г.`;
}

function updateReviewCount() {
    const totalCountElement = document.getElementById('total-reviews-count');
    const sectionCountElement = document.getElementById('reviews-section-count');
    const shownCountElement = document.getElementById('shown-reviews-count');
    const footerTotalElement = document.getElementById('footer-total-count');

    // РЕАЛЬНОЕ количество отзывов для показа (все что есть в массиве)
    const shownCount = Math.min(reviewsData.length, totalReviewsCount);

    if (totalCountElement) {
        totalCountElement.textContent = totalReviewsCount.toLocaleString('ru-RU');
    }

    if (sectionCountElement) {
        sectionCountElement.textContent = totalReviewsCount.toLocaleString('ru-RU');
    }

    if (shownCountElement) {
        shownCountElement.textContent = shownCount.toLocaleString('ru-RU');
    }
    
    if (footerTotalElement) {
        footerTotalElement.textContent = totalReviewsCount.toLocaleString('ru-RU');
    }
}

// Gift dropdown functionality
function initGiftDropdown() {
    const giftSelectBox = document.getElementById('gift-select-box');
    const giftSelectText = document.getElementById('gift-select-text');
    const giftInputHidden = document.getElementById('gift-input-hidden');
    const giftDropdown = document.getElementById('gift-dropdown');
    const giftSearchInput = document.getElementById('gift-search-input');
    const giftOptionsList = document.getElementById('gift-options-list');

    // Populate dropdown with all gifts
    giftItems.forEach(gift => {
        const option = document.createElement('div');
        option.className = 'gift-option';
        option.textContent = `🎁 ${gift}`;
        option.dataset.value = gift;
        
        option.addEventListener('click', function() {
            giftSelectText.textContent = gift;
            giftSelectText.classList.add('selected');
            giftInputHidden.value = gift;
            closeDropdown();
        });
        
        giftOptionsList.appendChild(option);
    });

    // Toggle dropdown on box click
    giftSelectBox.addEventListener('click', function(e) {
        e.stopPropagation();
        toggleDropdown();
    });

    // Filter gifts on search input
    giftSearchInput.addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        filterGifts(searchTerm);
    });

    // Prevent dropdown close when clicking search input
    giftSearchInput.addEventListener('click', function(e) {
        e.stopPropagation();
    });

    // Hide dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.gift-select-wrapper')) {
            closeDropdown();
        }
    });

    function toggleDropdown() {
        const isOpen = giftDropdown.classList.contains('show');
        if (isOpen) {
            closeDropdown();
        } else {
            openDropdown();
        }
    }

    function openDropdown() {
        giftDropdown.classList.add('show');
        giftSelectBox.classList.add('active');
        giftSearchInput.value = '';
        filterGifts('');
        setTimeout(() => giftSearchInput.focus(), 100);
    }

    function closeDropdown() {
        giftDropdown.classList.remove('show');
        giftSelectBox.classList.remove('active');
        giftSearchInput.value = '';
    }
}

function filterGifts(searchTerm) {
    const options = document.querySelectorAll('.gift-option');

    options.forEach(option => {
        const giftName = option.dataset.value.toLowerCase();
        if (giftName.includes(searchTerm)) {
            option.classList.remove('hidden');
        } else {
            option.classList.add('hidden');
        }
    });
}



// ========== ВОЛНОВАЯ АНИМАЦИЯ ПОЯВЛЕНИЯ ОТЗЫВОВ ==========
function addReviewsWaveAnimation() {
    const reviews = document.querySelectorAll('.review-item');
    
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry, index) => {
            if (entry.isIntersecting) {
                setTimeout(() => {
                    entry.target.classList.add('show');
                }, index * 50); // Задержка между элементами
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    reviews.forEach(review => {
        observer.observe(review);
    });
}

// Вызываем функцию после загрузки отзывов
setTimeout(addReviewsWaveAnimation, 500);

// ========== ЭФФЕКТ RIPPLE ДЛЯ КНОПКИ ==========
document.addEventListener('DOMContentLoaded', function() {
    const submitBtn = document.querySelector('.submit-button');
    
    if (submitBtn) {
        submitBtn.addEventListener('click', function(e) {
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.width = ripple.style.height = size + 'px';
            ripple.style.left = x + 'px';
            ripple.style.top = y + 'px';
            ripple.style.position = 'absolute';
            ripple.style.borderRadius = '50%';
            ripple.style.background = 'rgba(255, 255, 255, 0.6)';
            ripple.style.transform = 'scale(0)';
            ripple.style.animation = 'ripple 0.6s ease-out';
            ripple.style.pointerEvents = 'none';
            
            this.appendChild(ripple);
            
            setTimeout(() => ripple.remove(), 600);
        });
    }
    
    // Добавляем CSS для ripple анимации
    const style = document.createElement('style');
    style.textContent = `
        @keyframes ripple {
            to {
                transform: scale(2);
                opacity: 0;
            }
        }
        
        .submit-button {
            position: relative;
            overflow: hidden;
        }
    `;
    document.head.appendChild(style);
});


// Тема только тёмная — переключатель удалён.
