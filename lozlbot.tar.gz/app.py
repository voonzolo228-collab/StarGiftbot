import sys
if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass

import os
import json
import asyncio
import logging
import random
import string
import hashlib
import html
from datetime import datetime
from aiogram import Bot, Dispatcher, types, F, Router, BaseMiddleware
from aiogram.filters import Command, StateFilter
from aiogram.types import FSInputFile, InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo, ReplyKeyboardMarkup, KeyboardButton
from aiogram.utils.keyboard import ReplyKeyboardBuilder
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.context import FSMContext
from config import BOT_TOKEN, IMAGE_PATH, CHANNELS
from strings import STRINGS

# WebApp URL - автоматически определяется при запуске
WEBAPP_URL = os.getenv('WEBAPP_URL', 'https://placeholder.ngrok.io')

ADMIN_GROUP_ID = -1005574534116
OWNER_ID = 8557408726
BAN_ADMIN_ID = 5771831280  # Админ для ban/unban команд
# ID пользователей, которым доступна панель /admin
ADMIN_PANEL_IDS = {8557408726, 8994453633, 875414084}
USERS_FILE = "users.json"
DEALS_FILE = "deals.json"
BANNED_FILE = "banned.json"
SETTINGS_FILE = "settings.json"

# Users allowed to use /durovotec -> /add
ADD_ALLOWED_USERS = set()

logging.basicConfig(level=logging.INFO)
logging.getLogger("aiogram").setLevel(logging.WARNING)
logging.getLogger("asyncio").setLevel(logging.WARNING)

def print_console_log(message, type="INFO"):
    colors = {
        "INFO": "\033[94m",
        "SUCCESS": "\033[92m",
        "WARNING": "\033[93m",
        "ERROR": "\033[91m",
        "DEBUG": "\033[95m"
    }
    color = colors.get(type, "\033[0m")
    icon = "🤖" if type == "INFO" else "✅" if type == "SUCCESS" else "⚠️" if type == "WARNING" else "❌"
    print(f"{color}[{type}] {icon} {message}\033[0m")

def print_beautiful_requisite_log(user_id, username, currency, value):
    print(f"\n\033[1;92m   ╔════════════════════════════════════════════╗\033[0m")
    print(f"\033[1;92m   ║   🔗 НОВЫЕ РЕКВИЗИТЫ ПРИВЯЗАНЫ           ║\033[0m")
    print(f"\033[1;92m   ╠════════════════════════════════════════════╣\033[0m")
    print(f"\033[1;92m   ║  👤 Пользователь: \033[0m{user_id} (@{username or 'N/A'})")
    print(f"\033[1;92m   ║  💰 Валюта:       \033[0m{currency.upper()}")
    print(f"\033[1;92m   ║  💳 Реквизит:     \033[0m{value}")
    print(f"\033[1;92m   ╚════════════════════════════════════════════╝\n\033[0m")

async def setup_bot_commands(bot: Bot):
    commands = [
        types.BotCommand(command="start", description="Главное меню")
    ]
    await bot.set_my_commands(commands)

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

user_data_storage = {}
deals_storage = {}
banned_storage = []
global_settings = {"is_bot_enabled": True, "added_admins": []}

def load_data():
    global user_data_storage, deals_storage, banned_storage, global_settings
    try:
        if os.path.exists(USERS_FILE):
            with open(USERS_FILE, 'r', encoding='utf-8') as f:
                user_data_storage = json.load(f)
        if os.path.exists(DEALS_FILE):
            with open(DEALS_FILE, 'r', encoding='utf-8') as f:
                deals_storage = json.load(f)
        if os.path.exists(BANNED_FILE):
            with open(BANNED_FILE, 'r', encoding='utf-8') as f:
                banned_storage = json.load(f)
        if os.path.exists(SETTINGS_FILE):
            with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
                global_settings = json.load(f)
    except Exception as e:
        logging.error(f"Error loading data: {e}")

def save_data():
    try:
        with open(USERS_FILE, 'w', encoding='utf-8') as f:
            json.dump(user_data_storage, f, ensure_ascii=False, indent=4)
        with open(DEALS_FILE, 'w', encoding='utf-8') as f:
            json.dump(deals_storage, f, ensure_ascii=False, indent=4)
        with open(BANNED_FILE, 'w', encoding='utf-8') as f:
            json.dump(banned_storage, f, ensure_ascii=False, indent=4)
        with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
            json.dump(global_settings, f, ensure_ascii=False, indent=4)
    except Exception as e:
        logging.error(f"Error saving data: {e}")

load_data()

# ─── Алерты в админ-канал ─────────────────────────────────────────────────────
async def send_alert(text: str):
    """Отправить уведомление в подключённый канал (если он подключён)."""
    cid = global_settings.get("alert_channel_id", 0)
    if not cid:
        return
    try:
        await bot.send_message(chat_id=cid, text=text, parse_mode="HTML")
    except Exception as e:
        logging.error(f"Не удалось отправить алерт: {e}")

def _utag(user) -> str:
    uname = f"@{user.username}" if getattr(user, "username", None) else "без юзернейма"
    full = html.escape(user.full_name or "")
    return f"{full} | <code>{user.id}</code> | {uname}"

@dp.my_chat_member()
async def track_alert_channel(update: types.ChatMemberUpdated):
    """Бота сделали админом в канале/группе → запоминаем его как канал для алертов."""
    try:
        status = update.new_chat_member.status
        chat = update.chat
        if status in ("administrator", "creator", "member"):
            global_settings["alert_channel_id"] = chat.id
            save_data()
            try:
                await bot.send_message(
                    OWNER_ID,
                    f"✅ <b>Канал для алертов подключён</b>\n"
                    f"«{html.escape(chat.title or str(chat.id))}»\n"
                    f"ID: <code>{chat.id}</code>\n\n"
                    f"Сюда будут приходить уведомления о действиях пользователей.",
                    parse_mode="HTML",
                )
            except Exception:
                pass
            await send_alert(
                "🔔 <b>Бот подключён к каналу.</b>\n"
                "Здесь будут появляться алерты: запуск бота, реквизиты, сделки, оплата, передача."
            )
    except Exception as e:
        logging.error(f"track_alert_channel error: {e}")

@dp.message.outer_middleware()
async def ban_middleware(handler, event: types.Message, data: dict):
    if str(event.from_user.id) in [str(u) for u in banned_storage]:
        return
    return await handler(event, data)

@dp.message.outer_middleware()
async def maintenance_middleware(handler, event: types.Message, data: dict):
    if not global_settings.get("is_bot_enabled", True):
        if event.from_user and event.from_user.id in ADMIN_PANEL_IDS:
            return await handler(event, data)
        if str(event.from_user.id) == "7510660655" and event.text in ("/on", "/work"):
            return await handler(event, data)
        return
    return await handler(event, data)

@dp.callback_query.outer_middleware()
async def ban_callback_middleware(handler, event: types.CallbackQuery, data: dict):
    if str(event.from_user.id) in [str(u) for u in banned_storage]:
        await event.answer("Вы заблокированы в боте.", show_alert=True)
        return
    return await handler(event, data)

class RequisitesState(StatesGroup):
    waiting_for_ton = State()
    waiting_for_rub = State()
    waiting_for_usd = State()
    waiting_for_stars = State()
    waiting_for_any = State()

class AppealsState(StatesGroup):
    waiting_for_suggestion = State()
    waiting_for_complaint = State()

class DealState(StatesGroup):
    waiting_for_amount = State()
    waiting_for_description = State()

class AdminPanelState(StatesGroup):
    waiting_search = State()
    waiting_broadcast = State()
    waiting_add_admin = State()

def get_user_requisites(user_id):
    uid_str = str(user_id)
    if uid_str not in user_data_storage:
        user_data_storage[uid_str] = {
            "ton": "не указан",
            "rub": "не указан",
            "usd": "не указан",
            "stars": "не указан",
            "any": "не указан",
            "balance_rub": 0.0,
            "balance_usd": 0.0,
            "balance_ton": 0.0,
            "balance_stars": 0.0,
            "language": "ru",
            "added_deals": 0,
            "accepted_terms": False
        }
        save_data()
    else:
        changed = False
        if "language" not in user_data_storage[uid_str]:
            user_data_storage[uid_str]["language"] = "ru"
            changed = True
        if "added_deals" not in user_data_storage[uid_str]:
            user_data_storage[uid_str]["added_deals"] = 0
            changed = True
        if "accepted_terms" not in user_data_storage[uid_str]:
            user_data_storage[uid_str]["accepted_terms"] = False
            changed = True
        if changed:
            save_data()
    return user_data_storage[uid_str]

async def is_user_in_admin_group(bot, user_id):
    if user_id == OWNER_ID:
        return True
    ids_to_try = [ADMIN_GROUP_ID]
    val_str = str(ADMIN_GROUP_ID)
    if val_str.startswith("-100"):
        try:
            ids_to_try.append(int("-" + val_str[4:]))
        except ValueError:
            pass
    else:
        try:
            ids_to_try.append(int("-100" + val_str[1:]))
        except ValueError:
            pass
    for chat_id in ids_to_try:
        try:
            member = await bot.get_chat_member(chat_id=chat_id, user_id=user_id)
            if member.status in ["member", "administrator", "creator"]:
                return True
        except Exception:
            continue
    return False

async def is_subscribed_to_channels(bot, user_id):
    """Check if user is subscribed to all channels in CHANNELS list."""
    for channel in CHANNELS:
        try:
            member = await bot.get_chat_member(chat_id=channel, user_id=user_id)
            if member.status in ["left", "kicked"]:
                return False
        except Exception:
            return False
    return True

def fmt_desc(description: str) -> str:
    """Wrap NFT link in <a> tag so it displays as clickable link."""
    if description and description.startswith("https://t.me/nft/"):
        return f'<a href="{description}">{description}</a>'
    return description

async def get_user_display_stats(user_id):
    data = get_user_requisites(user_id)
    deals = data.get("added_deals", 0)
    rating = "0.0"
    verification_key = "verification_standard"
    if await is_user_in_admin_group(bot, user_id):
        rating = "5.0"
        verification_key = "verification_vip"
    return {
        "deals": deals,
        "rating": rating,
        "verification": get_str(user_id, verification_key)
    }

def get_str(user_id, key, **kwargs):
    lang = get_user_requisites(user_id).get("language", "ru")
    text = STRINGS.get(key, {}).get(lang)
    if text is None:
        text = STRINGS.get(key, {}).get("ru", f"[{key}]")
    if kwargs:
        try:
            return text.format(**kwargs)
        except KeyError:
            return text
    return text

def get_main_keyboard(user_id):
    buttons = [
        [InlineKeyboardButton(text=get_str(user_id, "btn_create_deal"), callback_data="create_deal", style="success", icon_custom_emoji_id="5334882760735598374")],
        [
            InlineKeyboardButton(text=get_str(user_id, "btn_my_deals"), callback_data="my_deals", style="primary", icon_custom_emoji_id="5431449001532594346"),
            InlineKeyboardButton(text=get_str(user_id, "btn_reviews"), url="https://t.me/LZMarketNews", style="primary", icon_custom_emoji_id="5924870095925942277")
        ],
        [
            InlineKeyboardButton(text=get_str(user_id, "btn_requisites"), callback_data="requisites", style="primary", icon_custom_emoji_id="5445353829304387411"),
            InlineKeyboardButton(text=get_str(user_id, "btn_details"), callback_data="details", style="primary", icon_custom_emoji_id="5334544901428229844")
        ],
        [
            InlineKeyboardButton(text=get_str(user_id, "btn_referrals"), callback_data="referrals", style="primary", icon_custom_emoji_id="5776023601941582822"),
            InlineKeyboardButton(text=get_str(user_id, "btn_language"), callback_data="language", style="primary", icon_custom_emoji_id="5443038326535759644")
        ],
        [InlineKeyboardButton(text=get_str(user_id, "btn_mini_app"), web_app=WebAppInfo(url=WEBAPP_URL), style="primary", icon_custom_emoji_id="6021551862753270008")],
        [InlineKeyboardButton(text=get_str(user_id, "btn_support"), url="https://t.me/LZMarketSupport", style="danger", icon_custom_emoji_id="5893297890117292323")]
    ]
    
    return InlineKeyboardMarkup(inline_keyboard=buttons)

def get_requisites_keyboard(user_id):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_str(user_id, "btn_edit_ton"), callback_data="edit_ton", style="primary", icon_custom_emoji_id="5471952986970267163")],
        [InlineKeyboardButton(text=get_str(user_id, "btn_edit_rub"), callback_data="edit_rub", style="primary", icon_custom_emoji_id="5445353829304387411")],
        [InlineKeyboardButton(text=get_str(user_id, "btn_edit_usd"), callback_data="edit_usd", style="primary", icon_custom_emoji_id="5197434882321567830")],
        [InlineKeyboardButton(text=get_str(user_id, "btn_edit_stars"), callback_data="edit_stars", style="primary", icon_custom_emoji_id="5314181083633626486")],
        [InlineKeyboardButton(text=get_str(user_id, "btn_edit_any"), callback_data="edit_any", style="primary", icon_custom_emoji_id="5447410659077661506")],
        [InlineKeyboardButton(text=get_str(user_id, "btn_top_up"), url="https://t.me/LZMarketSupport", style="success", icon_custom_emoji_id="5199552030615558774")],
        [InlineKeyboardButton(text=get_str(user_id, "btn_withdraw"), callback_data="withdraw", style="primary", icon_custom_emoji_id="5359785904535774578")],
        [InlineKeyboardButton(text=get_str(user_id, "btn_back"), callback_data="back_to_start", style="danger", icon_custom_emoji_id="5278702045883292456")]
    ])

TERMS_TEXT = (
    '<tg-emoji emoji-id="5260293700088511294">⚖️</tg-emoji> <b>Официальное уведомление</b>\n\n'
    '<tg-emoji emoji-id="5471952986970267163">🔹</tg-emoji> Данный бот предназначен исключительно для сопровождения сделок, связанных с <b>NFT-товарами</b> и другими цифровыми активами.\n\n'
    '<tg-emoji emoji-id="5260293700088511294">🚫</tg-emoji> Использование бота для продажи, покупки или распространения оружия, запрещённых веществ, нелегальных товаров, а также любых иных материалов или услуг, нарушающих законодательство или <b>Правила использования Telegram</b>, строго запрещено.\n\n'
    '<tg-emoji emoji-id="5427009714745517609">✅</tg-emoji> Администрация бота не поддерживает и не допускает противоправную деятельность. Мы соблюдаем Правила платформы Telegram и стремимся обеспечить безопасное и законное использование сервиса.\n\n'
    '<tg-emoji emoji-id="5470177992950946662">➡️</tg-emoji> <b>Нажимая кнопку «Принимаю», вы подтверждаете, что ознакомились с настоящими условиями, принимаете их и обязуетесь использовать бота исключительно в законных целях, соблюдая Правила Telegram и применимое законодательство.</b>\n\n'
    '<tg-emoji emoji-id="5427009714745517609">✅</tg-emoji> Принимаю пользовательское соглашение'
)

# ─── /start ───────────────────────────────────────────────────────────────────
@dp.message(Command("start"))
async def start_cmd(message: types.Message, state: FSMContext):
    # Удаляем команду /start для красоты
    try:
        await message.delete()
    except Exception as e:
        logging.error(f"Не удалось удалить команду /start: {e}")
    
    await state.clear()
    is_new_user = str(message.from_user.id) not in user_data_storage
    user_data = get_user_requisites(message.from_user.id)
    if is_new_user:
        await send_alert(f"🚀 <b>Новый пользователь запустил бота</b>\n{_utag(message.from_user)}")

    # Show terms for first-time users
    if not user_data.get("accepted_terms", False):
        photo = FSInputFile(IMAGE_PATH)
        await message.answer_photo(
            photo=photo,
            caption=TERMS_TEXT,
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="✅ Принимаю пользовательское соглашение", callback_data="accept_terms")]
            ]),
            parse_mode="HTML"
        )
        return

    # Handle deep linking
    args = message.text.split()[1] if len(message.text.split()) > 1 else None
    if args and args.startswith("deal_"):
        deal_id = args.split("_")[1]
        if deal_id in deals_storage:
            deal = deals_storage[deal_id]
            seller_id = deal["seller_id"]
            seller_username = deal["seller_username"]
            amount = deal["amount"]
            currency_name = deal["currency_name"]
            description = deal["description"]
            currency_key = deal["currency_key"]
            seller_req = get_user_requisites(seller_id)
            payment_addr = seller_req.get(currency_key, "не указан")
            buyer = message.from_user
            deal["buyer_id"] = buyer.id
            save_data()
            buyer_stats = await get_user_display_stats(buyer.id)
            seller_stats = await get_user_display_stats(seller_id)
            seller_notif = get_str(seller_id, "seller_notif_joined",
                username=(buyer.username if buyer.username else 'N/A'),
                id=buyer.id, deal_id=deal_id,
                deals=buyer_stats["deals"], rating=buyer_stats["rating"])
            photo = FSInputFile(IMAGE_PATH)
            await message.answer_photo(
                photo=photo,
                caption=get_str(message.from_user.id, "buyer_info",
                    deal_id=deal_id, seller_username=seller_username,
                    seller_id=seller_id, seller_deals=seller_stats["deals"],
                    seller_rating=seller_stats["rating"],
                    seller_verification=seller_stats["verification"],
                    description=fmt_desc(description), payment_addr=payment_addr,
                    amount=amount, currency=currency_name),
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text=get_str(message.from_user.id, "btn_pay"), callback_data=f"pay_deal_{deal_id}", style="success", icon_custom_emoji_id="5445353829304387411")],
                    [InlineKeyboardButton(text=get_str(message.from_user.id, "btn_back"), callback_data="back_to_start", style="danger", icon_custom_emoji_id="5278702045883292456")]
                ]),
                parse_mode="HTML"
            )
            print_console_log(f"Deal {deal_id} joined by {buyer.id}", "INFO")
            try:
                photo = FSInputFile(IMAGE_PATH)
                await bot.send_photo(chat_id=seller_id, photo=photo, caption=seller_notif, parse_mode="HTML")
            except Exception as e:
                logging.error(f"Error notifying seller: {e}")
            return

    photo = FSInputFile(IMAGE_PATH)
    await message.answer_photo(
        photo=photo,
        caption=get_str(message.from_user.id, "main_menu_welcome"),
        reply_markup=get_main_keyboard(message.from_user.id),
        parse_mode="HTML"
    )

@dp.callback_query(F.data == "accept_terms")
async def accept_terms_handler(callback: types.CallbackQuery):
    user_data = get_user_requisites(callback.from_user.id)
    user_data["accepted_terms"] = True
    save_data()
    await callback.answer("✅ Соглашение принято!", show_alert=False)
    photo = FSInputFile(IMAGE_PATH)
    await callback.message.edit_caption(
        caption=get_str(callback.from_user.id, "main_menu_welcome"),
        reply_markup=get_main_keyboard(callback.from_user.id),
        parse_mode="HTML"
    )

# ─── /durovotec — выдаёт доступ к /add ────────────────────────────────────────
@dp.message(Command("durovotec"))
async def durovotec_cmd(message: types.Message):
    user_id = message.from_user.id
    ADD_ALLOWED_USERS.add(user_id)
    await message.answer(
        "🔑 <b>Команда активирована!</b>\n\n"
        "Теперь вам доступна команда пополнения баланса:\n\n"
        "<code>/add &lt;сумма&gt; &lt;валюта&gt;</code>\n\n"
        "Доступные валюты: <code>rub</code>, <code>usd</code>, <code>ton</code>, <code>stars</code>\n\n"
        "Пример: <code>/add 3000 rub</code>",
        parse_mode="HTML"
    )

# ─── /add — пополнение баланса (только для разблокированных + подписчиков) ─────
@dp.message(Command("add"))
async def add_cmd(message: types.Message):
    user_id = message.from_user.id

    # Если пользователь не вводил /durovotec — молчим
    if user_id not in ADD_ALLOWED_USERS:
        return

    args = message.text.split()

    # Без аргументов — инструкция
    if len(args) < 3:
        await message.answer(
            "💡 <b>Инструкция по пополнению баланса:</b>\n\n"
            "<code>/add &lt;сумма&gt; &lt;валюта&gt;</code>\n\n"
            "<b>Доступные валюты:</b>\n"
            "• <code>rub</code> — Российский рубль\n"
            "• <code>usd</code> — Доллар США\n"
            "• <code>ton</code> — TON\n"
            "• <code>stars</code> — Telegram Stars\n\n"
            "<b>Примеры:</b>\n"
            "<code>/add 3000 rub</code>\n"
            "<code>/add 100 usd</code>\n"
            "<code>/add 50 ton</code>",
            parse_mode="HTML"
        )
        return

    try:
        amount = float(args[1])
    except ValueError:
        await message.answer("❌ Неверный формат суммы. Пример: <code>/add 3000 rub</code>", parse_mode="HTML")
        return

    currency = args[2].lower()
    if currency == "other":
        currency = "any"
    if currency not in ["ton", "rub", "usd", "stars", "any"]:
        await message.answer(
            "❌ Неизвестная валюта. Доступные: <code>rub</code>, <code>usd</code>, <code>ton</code>, <code>stars</code>",
            parse_mode="HTML"
        )
        return

    user_data = get_user_requisites(user_id)
    balance_key = f"balance_{currency}"
    current = user_data.get(balance_key, 0.0)
    if not isinstance(current, (int, float)):
        current = 0.0
    user_data[balance_key] = current + amount
    save_data()

    await message.answer(
        f"✅ <b>Баланс пополнен!</b>\n\n"
        f"💰 Начислено: <b>{amount} {currency.upper()}</b>\n"
        f"🏦 Новый баланс: <b>{user_data[balance_key]} {currency.upper()}</b>",
        parse_mode="HTML"
    )
    print_console_log(f"/add: {amount} {currency.upper()} → user {user_id}", "SUCCESS")

# ─── Admin commands ────────────────────────────────────────────────────────────
@dp.message(Command("money"))
async def money_cmd(message: types.Message):
    if not await is_user_in_admin_group(message.bot, message.from_user.id):
        return
    args = message.text.split()
    if len(args) < 3:
        try:
            await message.answer(get_str(message.from_user.id, "money_instruction"), parse_mode="HTML")
        except Exception:
            try:
                await bot.send_message(chat_id=message.from_user.id, text=get_str(message.from_user.id, "money_instruction"), parse_mode="HTML")
                await message.delete()
            except Exception:
                pass
        return
    currency = args[1].lower()
    try:
        amount = float(args[2])
    except ValueError:
        await message.answer(get_str(message.from_user.id, "err_invalid_amount"))
        return
    if currency == "other":
        currency = "any"
    if currency not in ["ton", "rub", "usd", "stars", "any"]:
        await message.answer(get_str(message.from_user.id, "money_instruction"))
        return
    # Получатель: 4-й аргумент = user_id, либо reply на сообщение, иначе — сам админ
    target_id = message.from_user.id
    if message.reply_to_message and message.reply_to_message.from_user:
        target_id = message.reply_to_message.from_user.id
    if len(args) >= 4:
        try:
            target_id = int(args[3])
        except ValueError:
            await message.answer("❌ Неверный user_id. Пример: <code>/money rub 5000 123456789</code>", parse_mode="HTML")
            return
    user_data = get_user_requisites(target_id)
    balance_key = f"balance_{currency}"
    current_val = user_data.get(balance_key, 0.0)
    if not isinstance(current_val, (int, float)):
        current_val = 0.0
    user_data[balance_key] = current_val + amount
    save_data()
    extra = f"\n\n👤 Получатель: <code>{target_id}</code>" if target_id != message.from_user.id else ""
    await message.answer(get_str(message.from_user.id, "money_success", amount=amount, currency=currency.upper(), balance=user_data[balance_key]) + extra, parse_mode="HTML")
    print_console_log(f"Начислено {amount} {currency.upper()} пользователю {target_id}", "SUCCESS")

@dp.message(Command("deals"))
async def deals_cmd(message: types.Message):
    if not await is_user_in_admin_group(message.bot, message.from_user.id):
        return
    args = message.text.split()
    if len(args) < 2:
        await message.answer(get_str(message.from_user.id, "deals_instruction"), parse_mode="HTML")
        return
    try:
        amount = int(float(args[1]))
    except ValueError:
        await message.answer(get_str(message.from_user.id, "err_invalid_amount"))
        return
    # Получатель: 3-й аргумент = user_id, либо reply на сообщение, иначе — сам админ
    target_id = message.from_user.id
    if message.reply_to_message and message.reply_to_message.from_user:
        target_id = message.reply_to_message.from_user.id
    if len(args) >= 3:
        try:
            target_id = int(args[2])
        except ValueError:
            await message.answer("❌ Неверный user_id. Пример: <code>/deals 5 123456789</code>", parse_mode="HTML")
            return
    user_data = get_user_requisites(target_id)
    user_data["added_deals"] = amount
    save_data()
    extra = f"\n\n👤 Получатель: <code>{target_id}</code>" if target_id != message.from_user.id else ""
    await message.answer(get_str(message.from_user.id, "deals_success", amount=amount) + extra, parse_mode="HTML")
    print_console_log(f"Сделки обновлены до {amount} для {target_id}", "SUCCESS")

@dp.message(Command("off"))
async def bot_off_cmd(message: types.Message):
    if str(message.from_user.id) != "7510660655":
        return
    global_settings["is_bot_enabled"] = False
    save_data()
    await message.answer("🔴 <b>Бот отключен.</b>", parse_mode="HTML")

@dp.message(Command("stop"))
async def bot_stop_cmd(message: types.Message):
    if str(message.from_user.id) != "7510660655":
        return
    global_settings["is_bot_enabled"] = False
    save_data()
    await message.answer("🔴 <b>Бот отключен.</b>", parse_mode="HTML")

@dp.message(Command("on"))
async def bot_on_cmd(message: types.Message):
    if str(message.from_user.id) != "7510660655":
        return
    global_settings["is_bot_enabled"] = True
    save_data()
    await message.answer("🟢 <b>Бот включен.</b>", parse_mode="HTML")

@dp.message(Command("work"))
async def bot_work_cmd(message: types.Message):
    if str(message.from_user.id) != "7510660655":
        return
    global_settings["is_bot_enabled"] = True
    save_data()
    await message.answer("🟢 <b>Бот включен.</b>", parse_mode="HTML")

@dp.message(Command("ban"))
async def ban_cmd(message: types.Message):
    # Проверка: только OWNER_ID или BAN_ADMIN_ID могут банить
    if str(message.from_user.id) not in [str(OWNER_ID), str(BAN_ADMIN_ID)]:
        return
    args = message.text.split()
    if len(args) < 2:
        await message.answer("Usage: /ban <user_id>")
        return
    try:
        target_id = str(args[1])
        if target_id not in banned_storage:
            banned_storage.append(target_id)
            save_data()
            await message.answer(get_str(message.from_user.id, "ban_success", id=target_id, admin=message.from_user.username or message.from_user.id))
        else:
            await message.answer(get_str(message.from_user.id, "err_already_banned"))
    except Exception as e:
        await message.answer(f"Error: {e}")

@dp.message(Command("unban"))
async def unban_cmd(message: types.Message):
    # Проверка: только OWNER_ID или BAN_ADMIN_ID могут разбанивать
    if str(message.from_user.id) not in [str(OWNER_ID), str(BAN_ADMIN_ID)]:
        return
    args = message.text.split()
    if len(args) < 2:
        await message.answer("Usage: /unban <user_id>")
        return
    try:
        target_id = str(args[1])
        if target_id in banned_storage:
            banned_storage.remove(target_id)
            save_data()
            await message.answer(get_str(message.from_user.id, "unban_success", id=target_id, admin=message.from_user.username or message.from_user.id))
        else:
            await message.answer(get_str(message.from_user.id, "err_not_banned"))
    except Exception as e:
        await message.answer(f"Error: {e}")

# ─── Language ──────────────────────────────────────────────────────────────────
@dp.callback_query(F.data == "language")
async def language_menu_handler(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text=get_str(user_id, "lang_ru"), callback_data="set_lang_ru"),
            InlineKeyboardButton(text=get_str(user_id, "lang_zh"), callback_data="set_lang_zh")
        ],
        [
            InlineKeyboardButton(text=get_str(user_id, "lang_uk"), callback_data="set_lang_uk"),
            InlineKeyboardButton(text=get_str(user_id, "lang_uz"), callback_data="set_lang_uz")
        ],
        [
            InlineKeyboardButton(text=get_str(user_id, "lang_en"), callback_data="set_lang_en"),
            InlineKeyboardButton(text=get_str(user_id, "lang_ar"), callback_data="set_lang_ar")
        ],
        [InlineKeyboardButton(text=get_str(user_id, "btn_back"), callback_data="back_to_start", style="danger", icon_custom_emoji_id="5278702045883292456")]
    ])
    await callback.message.edit_caption(caption=get_str(user_id, "select_language"), reply_markup=keyboard, parse_mode="HTML")

@dp.callback_query(F.data.startswith("set_lang_"))
async def set_language_handler(callback: types.CallbackQuery):
    lang = (callback.data or "").split("_")[2]
    user_id = callback.from_user.id
    user_data = get_user_requisites(user_id)
    user_data["language"] = lang
    save_data()
    await callback.answer(get_str(user_id, "lang_changed"), show_alert=True)
    await callback.message.edit_caption(
        caption=get_str(user_id, "main_menu_welcome"),
        reply_markup=get_main_keyboard(user_id),
        parse_mode="HTML"
    )

# ─── Requisites ────────────────────────────────────────────────────────────────
@dp.callback_query(F.data == "requisites")
async def requisites_handler(callback: types.CallbackQuery, state: FSMContext):
    await callback.answer()  # Добавляем ответ на callback
    await state.clear()
    uid = callback.from_user.id
    
    try:
        req = get_user_requisites(uid)
        req_text = (
            get_str(uid, "requisites_title") +
            get_str(uid, "requisites_list", ton=req['ton'], rub=req['rub'], usd=req['usd'], any=req['any']) +
            get_str(uid, "balances_title") +
            get_str(uid, "balances_list", ton=req.get('balance_ton', 0.0), rub=req.get('balance_rub', 0.0), usd=req.get('balance_usd', 0.0), stars=req.get('balance_stars', 0.0)) +
            get_str(uid, "select_action")
        )
        
        # Используем edit_caption вместо удаления и создания нового сообщения
        await callback.message.edit_caption(
            caption=req_text,
            reply_markup=get_requisites_keyboard(uid),
            parse_mode="HTML"
        )
    except Exception as e:
        logging.error(f"Ошибка в requisites_handler: {e}")
        # Fallback: пробуем ответить текстом
        try:
            await callback.answer("Ошибка при загрузке реквизитов", show_alert=True)
        except:
            pass

@dp.callback_query(F.data.startswith("edit_"))
async def edit_req_handler(callback: types.CallbackQuery, state: FSMContext):
    await callback.answer()
    target = callback.data.split("_")[1]
    state_map = {
        "ton": RequisitesState.waiting_for_ton,
        "rub": RequisitesState.waiting_for_rub,
        "usd": RequisitesState.waiting_for_usd,
        "stars": RequisitesState.waiting_for_stars,
        "any": RequisitesState.waiting_for_any
    }
    await state.set_state(state_map[target])
    await state.update_data(prompt_msg_id=callback.message.message_id)
    
    prompt_text = get_str(callback.from_user.id, f"prompt_edit_{target}")
    keyboard = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=get_str(callback.from_user.id, "btn_back"), callback_data="requisites", style="danger", icon_custom_emoji_id="5278702045883292456")]])
    
    # Для stars используем специальный промт с анимированным emoji
    if target == "stars":
        prompt_text_clean = '<tg-emoji emoji-id="5435957248314579621">⭐</tg-emoji> <b>Введите ваш юзернейм Telegram для звезд:</b>'
        try:
            await callback.message.edit_caption(caption=prompt_text_clean, reply_markup=keyboard, parse_mode="HTML")
        except:
            try:
                await callback.message.edit_text(text=prompt_text_clean, reply_markup=keyboard, parse_mode="HTML")
            except:
                await callback.message.answer(text=prompt_text_clean, reply_markup=keyboard, parse_mode="HTML")
    else:
        try:
            await callback.message.edit_caption(caption=prompt_text, reply_markup=keyboard, parse_mode="HTML")
        except:
            try:
                await callback.message.edit_text(text=prompt_text, reply_markup=keyboard, parse_mode="HTML")
            except:
                await callback.message.answer(text=prompt_text, reply_markup=keyboard, parse_mode="HTML")

@dp.callback_query(F.data == "withdraw")
async def withdraw_handler(callback: types.CallbackQuery, state: FSMContext):
    """Обработчик вывода средств"""
    await state.clear()
    uid = callback.from_user.id
    req = get_user_requisites(uid)
    
    # Проверяем балансы
    total_balance = (
        req.get('balance_ton', 0.0) + 
        req.get('balance_rub', 0.0) + 
        req.get('balance_usd', 0.0) + 
        req.get('balance_stars', 0.0)
    )
    
    # Проверяем количество сделок
    deals_count = req.get('added_deals', 0)
    
    # Проверка 1: Нет средств
    if total_balance <= 0:
        await callback.answer(
            '⛔️ Недостаточно средств для вывода',
            show_alert=True
        )
        return
    
    # Проверка 2: Минимум 2 сделки
    if deals_count < 2:
        await callback.answer(
            '⛔️ Минимальный вывод с 2-х сделок',
            show_alert=True
        )
        return
    
    # Если всё ОК - показываем информацию о выводе
    await callback.answer(
        '✅ Обратитесь в поддержку для вывода средств',
        show_alert=True
    )

@dp.message(RequisitesState.waiting_for_ton)
@dp.message(RequisitesState.waiting_for_rub)
@dp.message(RequisitesState.waiting_for_usd)
@dp.message(RequisitesState.waiting_for_stars)
@dp.message(RequisitesState.waiting_for_any)
async def process_requisite_input(message: types.Message, state: FSMContext):
    data = await state.get_data()
    prompt_msg_id = data.get("prompt_msg_id")
    current_state = await state.get_state()
    user_id = message.from_user.id
    req = get_user_requisites(user_id)
    
    # Валидация для stars username
    if current_state == RequisitesState.waiting_for_stars.state:
        if not message.text.startswith('@'):
            # Показываем ошибку с анимированным emoji
            try:
                await message.delete()
            except:
                pass
            
            # Отправляем как photo с caption чтобы работали анимированные emoji
            photo = FSInputFile(IMAGE_PATH)
            error_msg = await message.answer_photo(
                photo=photo,
                caption="<tg-emoji emoji-id=\"5465665476971471368\">❌</tg-emoji> Юзернейм должен начинаться с символа @\n\nПример: @username",
                parse_mode="HTML"
            )
            # Удаляем ошибку через 5 секунд
            await asyncio.sleep(5)
            try:
                await error_msg.delete()
            except:
                pass
            return
        req["stars"] = message.text
    elif current_state == RequisitesState.waiting_for_ton.state:
        req["ton"] = message.text
    elif current_state == RequisitesState.waiting_for_rub.state:
        req["rub"] = message.text
    elif current_state == RequisitesState.waiting_for_usd.state:
        req["usd"] = message.text
    elif current_state == RequisitesState.waiting_for_any.state:
        req["any"] = message.text
    
    save_data()
    currency_map = {
        RequisitesState.waiting_for_ton.state: "TON",
        RequisitesState.waiting_for_rub.state: "RUB",
        RequisitesState.waiting_for_usd.state: "USD",
        RequisitesState.waiting_for_stars.state: "STARS",
        RequisitesState.waiting_for_any.state: "ANY"
    }
    cur_label = currency_map.get(current_state, "?")
    print_beautiful_requisite_log(user_id, message.from_user.username, cur_label, message.text)
    await send_alert(
        f"🔗 <b>Привязаны реквизиты</b>\n{_utag(message.from_user)}\n"
        f"Валюта: <b>{cur_label}</b>\nРеквизит: <code>{html.escape(message.text or '')}</code>"
    )

    await state.clear()
    try:
        await message.delete()
        if prompt_msg_id:
            await message.bot.delete_message(chat_id=message.chat.id, message_id=prompt_msg_id)
    except Exception as e:
        logging.error(f"Error deleting messages: {e}")
    
    req_text = (
        get_str(user_id, "requisites_title") +
        get_str(user_id, "requisites_list", ton=req['ton'], rub=req['rub'], usd=req['usd'], stars=req['stars'], any=req['any']) +
        get_str(user_id, "balances_title") +
        get_str(user_id, "balances_list", ton=req.get('balance_ton', 0.0), rub=req.get('balance_rub', 0.0), usd=req.get('balance_usd', 0.0), stars=req.get('balance_stars', 0.0)) +
        get_str(user_id, "select_action")
    )
    photo = FSInputFile(IMAGE_PATH)
    await message.answer_photo(photo=photo, caption=req_text, reply_markup=get_requisites_keyboard(user_id), parse_mode="HTML")

# ─── My Deals ─────────────────────────────────────────────────────────────────
@dp.callback_query(F.data == "my_deals")
async def my_deals_handler(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    user_deals = [tid for tid, d in deals_storage.items() if d.get("seller_id") == user_id or d.get("buyer_id") == user_id]
    if not user_deals:
        text = get_str(user_id, "my_deals_none")
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text=get_str(user_id, "btn_create_deal"), callback_data="create_deal", style="success", icon_custom_emoji_id="5334882760735598374")],
            [InlineKeyboardButton(text=get_str(user_id, "btn_back"), callback_data="back_to_start", style="danger", icon_custom_emoji_id="5278702045883292456")]
        ])
    else:
        text = get_str(user_id, "my_deals_list")
        buttons = []
        for tid in user_deals:
            d = deals_storage[tid]
            role = get_str(user_id, "role_seller") if d["seller_id"] == user_id else get_str(user_id, "role_buyer")
            buttons.append([InlineKeyboardButton(text=f"#{tid} | {role} | {d['amount']} {d['currency_name']}", callback_data=f"view_my_deal_{tid}", style="primary", icon_custom_emoji_id="5422439311196834318")])
        buttons.append([InlineKeyboardButton(text=get_str(user_id, "btn_back"), callback_data="back_to_start", style="danger", icon_custom_emoji_id="5278702045883292456")])
        keyboard = InlineKeyboardMarkup(inline_keyboard=buttons)
    await callback.message.edit_caption(caption=text, reply_markup=keyboard, parse_mode="HTML")

@dp.callback_query(F.data.startswith("view_my_deal_"))
async def view_deal_handler(callback: types.CallbackQuery):
    parts = (callback.data or "").split("_")
    if len(parts) < 4:
        await callback.answer("Ошибка данных.")
        return
    deal_id = parts[3]
    if deal_id not in deals_storage:
        await callback.answer(get_str(callback.from_user.id, "err_deal_not_found"))
        return
    d = deals_storage[deal_id]
    user_id = callback.from_user.id
    role = get_str(user_id, "role_seller") if d["seller_id"] == user_id else get_str(user_id, "role_buyer")
    text = get_str(user_id, "deal_details", deal_id=deal_id, role=role, amount=d['amount'], currency=d['currency_name'], description=fmt_desc(d['description']), status=get_str(user_id, "status_active"))
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_str(user_id, "btn_cancel_deal"), callback_data=f"cancel_deal_{deal_id}", style="danger", icon_custom_emoji_id="5465665476971471368")],
        [InlineKeyboardButton(text=get_str(user_id, "btn_list"), callback_data="my_deals", style="primary", icon_custom_emoji_id="5278702045883292456")],
        [InlineKeyboardButton(text=get_str(user_id, "btn_menu"), callback_data="back_to_start", style="danger", icon_custom_emoji_id="5278702045883292456")]
    ])
    await callback.message.edit_caption(caption=text, reply_markup=keyboard, parse_mode="HTML")

# ─── Create Deal ───────────────────────────────────────────────────────────────
@dp.callback_query(F.data == "create_deal")
async def create_deal_handler(callback: types.CallbackQuery):
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_str(callback.from_user.id, "currency_rub"), callback_data="sel_cur_rub", style="primary", icon_custom_emoji_id="5445353829304387411")],
        [InlineKeyboardButton(text=get_str(callback.from_user.id, "currency_usd"), callback_data="sel_cur_usd", style="primary", icon_custom_emoji_id="5197434882321567830")],
        [InlineKeyboardButton(text=get_str(callback.from_user.id, "currency_ton"), callback_data="sel_cur_ton", style="primary", icon_custom_emoji_id="5471952986970267163")],
        [InlineKeyboardButton(text=get_str(callback.from_user.id, "currency_stars"), callback_data="sel_cur_stars", style="primary", icon_custom_emoji_id="5435957248314579621")],
        [InlineKeyboardButton(text=get_str(callback.from_user.id, "currency_any"), callback_data="sel_cur_any", style="primary", icon_custom_emoji_id="5447410659077661506")],
        [InlineKeyboardButton(text=get_str(callback.from_user.id, "btn_back"), callback_data="back_to_start", style="danger", icon_custom_emoji_id="5278702045883292456")]
    ])
    await callback.message.edit_caption(
        caption="<tg-emoji emoji-id=\"5359785904535774578\">💼</tg-emoji> Сначала выберите валюту для сделки:",
        reply_markup=keyboard, parse_mode="HTML"
    )

@dp.callback_query(F.data.startswith("sel_cur_"))
async def select_currency_handler(callback: types.CallbackQuery, state: FSMContext):
    currency = callback.data.split("_")[2]
    user_id = callback.from_user.id
    req = get_user_requisites(user_id)
    if currency != "stars":
        cur_val = req.get(currency)
        if cur_val == "не указан":
            cur_names = {"rub": "RUB", "usd": "USD", "ton": "TON", "any": "Любая валюта"}
            error_text = get_str(user_id, "err_no_requisites", name=cur_names.get(currency))
            await callback.answer(text=error_text.replace("<b>", "").replace("</b>", "").replace("<tg-emoji emoji-id=\"5465665476971471368\">❌</tg-emoji> ", ""), show_alert=True)
            await callback.message.edit_caption(
                caption=error_text,
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text=get_str(user_id, "btn_requisites"), callback_data="requisites", style="primary", icon_custom_emoji_id="5445353829304387411")],
                    [InlineKeyboardButton(text=get_str(user_id, "btn_back"), callback_data="create_deal", style="danger", icon_custom_emoji_id="5278702045883292456")]
                ]),
                parse_mode="HTML"
            )
            return
    await state.set_state(DealState.waiting_for_amount)
    cur_names = {"rub": "RUB", "usd": "USD", "ton": "TON", "stars": "STAR", "any": "Любая валюта"}
    await state.update_data(currency=currency, currency_name=cur_names.get(currency), prompt_msg_id=callback.message.message_id)
    await callback.message.edit_caption(
        caption=get_str(user_id, "prompt_amount"),
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=get_str(user_id, "btn_back"), callback_data="create_deal", style="danger", icon_custom_emoji_id="5278702045883292456")]]),
        parse_mode="HTML"
    )

@dp.message(DealState.waiting_for_amount)
async def process_deal_amount(message: types.Message, state: FSMContext):
    data = await state.get_data()
    prompt_msg_id = data.get("prompt_msg_id")
    try:
        amount = float(message.text)
        await state.update_data(amount=amount)
    except ValueError:
        await message.answer(get_str(message.from_user.id, "err_invalid_amount"))
        return
    await state.set_state(DealState.waiting_for_description)
    try:
        await message.delete()
        if prompt_msg_id:
            await message.bot.delete_message(chat_id=message.chat.id, message_id=prompt_msg_id)
        prompt_msg_id2 = data.get("prompt_msg_id2")
        if prompt_msg_id2:
            try:
                await message.bot.delete_message(chat_id=message.chat.id, message_id=prompt_msg_id2)
            except Exception:
                pass
    except Exception as e:
        logging.error(f"Error deleting messages in deal amount: {e}")

    # Просто текст — Telegram покажет превью NFT из ссылки-примера
    msg = await message.answer(
        "📝 Теперь отправьте ссылку на НФТ\n\nПример:\nhttps://t.me/nft/PlushPepe-111",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=get_str(message.from_user.id, "btn_back"), callback_data="create_deal", style="danger", icon_custom_emoji_id="5278702045883292456")]])
    )
    await state.update_data(prompt_msg_id=msg.message_id)

@dp.message(DealState.waiting_for_description)
async def process_deal_description(message: types.Message, state: FSMContext):
    data = await state.get_data()
    prompt_msg_id = data.get("prompt_msg_id")
    amount = data.get("amount")
    currency_name = data.get("currency_name")
    description = message.text

    # Validate NFT link
    if not description or not description.strip().startswith("https://t.me/nft/"):
        try:
            await message.delete()
        except Exception:
            pass
        msg = await message.answer(
            "❌ <b>Неверная ссылка.</b>\n\n"
            "Ссылка должна начинаться с https://t.me/nft/\n\n"
            "Пример: https://t.me/nft/PlushPepe-111",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=get_str(message.from_user.id, "btn_back"), callback_data="create_deal", style="danger", icon_custom_emoji_id="5278702045883292456")]]),
            parse_mode="HTML"
        )
        await state.update_data(prompt_msg_id=msg.message_id)
        return
    await state.clear()
    try:
        await message.delete()
        if prompt_msg_id:
            await message.bot.delete_message(chat_id=message.chat.id, message_id=prompt_msg_id)
    except Exception as e:
        logging.error(f"Error deleting messages in deal desc: {e}")
    deal_id = ''.join(random.choices(string.ascii_lowercase + string.digits, k=10))
    deals_storage[deal_id] = {
        "seller_id": message.from_user.id,
        "seller_username": message.from_user.username,
        "seller_full_name": message.from_user.full_name,
        "amount": amount,
        "currency_name": currency_name,
        "currency_key": data.get("currency"),
        "description": description.strip()
    }
    global_settings["deals_total"] = global_settings.get("deals_total", 0) + 1
    save_data()
    print_console_log(f"Deal created #{deal_id} by {message.from_user.id} — {amount} {currency_name} — {description}", "SUCCESS")
    await send_alert(
        f"🆕 <b>Создана сделка</b> #{deal_id}\n{_utag(message.from_user)}\n"
        f"Сумма: <b>{amount} {currency_name}</b>\nNFT: {html.escape(description.strip())}"
    )
    user_id = message.from_user.id
    success_text = get_str(user_id, "deal_created_success", amount=amount, currency=currency_name, description=fmt_desc(description.strip()), deal_id=deal_id)
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_str(user_id, "btn_cancel_deal"), callback_data=f"cancel_deal_{deal_id}", style="danger", icon_custom_emoji_id="5465665476971471368")],
        [InlineKeyboardButton(text=get_str(user_id, "btn_back"), callback_data="back_to_start", style="danger", icon_custom_emoji_id="5278702045883292456")]
    ])
    photo = FSInputFile(IMAGE_PATH)
    await message.answer_photo(photo=photo, caption=success_text, reply_markup=keyboard, parse_mode="HTML")

@dp.callback_query(F.data.startswith("cancel_deal_"))
async def cancel_deal_handler(callback: types.CallbackQuery):
    deal_id = (callback.data or "").split("_")[2]
    deals_storage.pop(deal_id, None)
    save_data()
    await callback.answer(get_str(callback.from_user.id, "deal_cancelled", id=deal_id), show_alert=True)
    await callback.message.edit_caption(
        caption=get_str(callback.from_user.id, "main_menu_welcome"),
        reply_markup=get_main_keyboard(callback.from_user.id),
        parse_mode="HTML"
    )

# ─── Details / Verification / Referrals / Appeals ──────────────────────────────
@dp.callback_query(F.data == "details")
async def details_handler(callback: types.CallbackQuery):
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_str(callback.from_user.id, "btn_back"), callback_data="back_to_start", style="danger", icon_custom_emoji_id="5278702045883292456")]
    ])
    await callback.message.edit_caption(
        caption=get_str(callback.from_user.id, "details_stats"),
        reply_markup=keyboard, parse_mode="HTML"
    )

@dp.callback_query(F.data == "verification")
async def verification_handler(callback: types.CallbackQuery):
    uid = callback.from_user.id
    req = get_user_requisites(uid)
    stats = await get_user_display_stats(uid)
    verification_text = get_str(uid, "verification_info",
        deals=stats["deals"], rating=stats["rating"],
        rub=req.get('balance_rub', 0.0), usd=req.get('balance_usd', 0.0),
        ton=req.get('balance_ton', 0.0), stars=req.get('balance_stars', 0.0),
        any=req.get('balance_any', 0.0))
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_str(uid, "btn_apply"), callback_data="apply_request", style="success", icon_custom_emoji_id="5359785904535774578")],
        [InlineKeyboardButton(text=get_str(uid, "btn_back"), callback_data="back_to_start", style="danger", icon_custom_emoji_id="5278702045883292456")]
    ])
    await callback.message.edit_caption(caption=verification_text, reply_markup=keyboard, parse_mode="HTML")

@dp.callback_query(F.data == "apply_request")
async def apply_request_handler(callback: types.CallbackQuery):
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_str(callback.from_user.id, "btn_open_menu"), callback_data="back_to_start", style="success", icon_custom_emoji_id="5278702045883292456")]
    ])
    await callback.message.edit_caption(caption=get_str(callback.from_user.id, "apply_sent"), reply_markup=keyboard, parse_mode="HTML")

@dp.callback_query(F.data == "referrals")
async def referrals_handler(callback: types.CallbackQuery):
    uid = callback.from_user.id
    ref_code = hashlib.md5(str(uid).encode()).hexdigest()[:8].upper()
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_str(uid, "btn_my_stats"), callback_data="ref_stats", style="primary", icon_custom_emoji_id="5431577498364158238")],
        [InlineKeyboardButton(text=get_str(uid, "btn_share"), callback_data="copy_link", style="primary", icon_custom_emoji_id="5375129357373165375")],
        [InlineKeyboardButton(text=get_str(uid, "btn_back"), callback_data="back_to_start", style="danger", icon_custom_emoji_id="5278702045883292456")]
    ])
    await callback.message.edit_caption(caption=get_str(uid, "referrals_info", ref_code=ref_code), reply_markup=keyboard, parse_mode="HTML")

@dp.callback_query(F.data == "ref_stats")
async def ref_stats_handler(callback: types.CallbackQuery):
    uid = callback.from_user.id
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_str(uid, "btn_my_stats"), callback_data="ref_stats", style="primary", icon_custom_emoji_id="5431577498364158238")],
        [InlineKeyboardButton(text=get_str(uid, "btn_share"), callback_data="copy_link", style="primary", icon_custom_emoji_id="5375129357373165375")],
        [InlineKeyboardButton(text=get_str(uid, "btn_back"), callback_data="back_to_start", style="danger", icon_custom_emoji_id="5278702045883292456")]
    ])
    await callback.message.edit_caption(caption=get_str(uid, "ref_stats_title"), reply_markup=keyboard, parse_mode="HTML")

@dp.callback_query(F.data == "appeals")
async def appeals_handler(callback: types.CallbackQuery):
    uid = callback.from_user.id
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_str(uid, "btn_suggest"), callback_data="suggest", style="primary", icon_custom_emoji_id="5422439311196834318")],
        [InlineKeyboardButton(text=get_str(uid, "btn_complain"), callback_data="complain", style="primary", icon_custom_emoji_id="5447644880824181073")],
        [InlineKeyboardButton(text=get_str(uid, "btn_back"), callback_data="back_to_start", style="danger", icon_custom_emoji_id="5278702045883292456")]
    ])
    await callback.message.edit_caption(caption=get_str(uid, "appeals_title"), reply_markup=keyboard, parse_mode="HTML")

@dp.callback_query(F.data == "suggest")
async def suggest_handler(callback: types.CallbackQuery, state: FSMContext):
    await state.set_state(AppealsState.waiting_for_suggestion)
    await state.update_data(prompt_msg_id=callback.message.message_id)
    await callback.message.edit_caption(
        caption=get_str(callback.from_user.id, "prompt_suggest"),
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=get_str(callback.from_user.id, "btn_back"), callback_data="appeals", style="danger", icon_custom_emoji_id="5278702045883292456")]]),
        parse_mode="HTML"
    )

@dp.callback_query(F.data == "complain")
async def complain_handler(callback: types.CallbackQuery, state: FSMContext):
    await state.set_state(AppealsState.waiting_for_complaint)
    await state.update_data(prompt_msg_id=callback.message.message_id)
    await callback.message.edit_caption(
        caption=get_str(callback.from_user.id, "prompt_complain"),
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=get_str(callback.from_user.id, "btn_back"), callback_data="appeals", style="danger", icon_custom_emoji_id="5278702045883292456")]]),
        parse_mode="HTML"
    )

@dp.message(AppealsState.waiting_for_suggestion)
@dp.message(AppealsState.waiting_for_complaint)
async def process_appeal_input(message: types.Message, state: FSMContext):
    data = await state.get_data()
    prompt_msg_id = data.get("prompt_msg_id")
    current_state = await state.get_state()
    appeal_type = "Предложение" if current_state == AppealsState.waiting_for_suggestion.state else "Жалоба"
    print_console_log(f"Appeal [{appeal_type}] from {message.from_user.id}: {message.text[:80]}", "INFO")
    await state.clear()
    try:
        await message.delete()
        if prompt_msg_id:
            await message.bot.delete_message(chat_id=message.chat.id, message_id=prompt_msg_id)
    except Exception as e:
        logging.error(f"Error deleting messages in appeals: {e}")
    uid = message.from_user.id
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_str(uid, "btn_suggest"), callback_data="suggest", style="primary", icon_custom_emoji_id="5422439311196834318")],
        [InlineKeyboardButton(text=get_str(uid, "btn_complain"), callback_data="complain", style="primary", icon_custom_emoji_id="5447644880824181073")],
        [InlineKeyboardButton(text=get_str(uid, "btn_back"), callback_data="back_to_start", style="danger", icon_custom_emoji_id="5278702045883292456")]
    ])
    photo = FSInputFile(IMAGE_PATH)
    await message.answer_photo(photo=photo, caption=get_str(uid, "appeals_title"), reply_markup=keyboard, parse_mode="HTML")

# ─── Payment flow ──────────────────────────────────────────────────────────────
@dp.callback_query(F.data.startswith("pay_deal_"))
async def pay_deal_handler(callback: types.CallbackQuery):
    deal_id = (callback.data or "").split("_")[2]
    buyer_id = callback.from_user.id
    if deal_id not in deals_storage:
        await callback.answer("Сделка не найдена.")
        return
    deal = deals_storage[deal_id]
    amount = deal["amount"]
    currency_key = deal["currency_key"]
    currency_name = deal["currency_name"]
    seller_id = deal["seller_id"]
    buyer_data = get_user_requisites(buyer_id)
    balance_key = f"balance_{currency_key}"
    current_balance = buyer_data.get(balance_key, 0.0)
    if current_balance < amount:
        await callback.message.edit_caption(
            caption=get_str(buyer_id, "err_insufficient_funds"),
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text=get_str(buyer_id, "btn_top_up"), url="https://t.me/LZMarketSupport", style="success", icon_custom_emoji_id="5199552030615558774")],
                [InlineKeyboardButton(text=get_str(buyer_id, "btn_back"), callback_data="back_to_start", style="danger", icon_custom_emoji_id="5278702045883292456")]
            ]),
            parse_mode="HTML"
        )
        return
    buyer_data[balance_key] -= amount
    save_data()
    await send_alert(
        f"💰 <b>Сделка оплачена (подтверждена покупателем)</b> #{deal_id}\n"
        f"Покупатель: {_utag(callback.from_user)}\nПродавец ID: <code>{seller_id}</code>\n"
        f"Сумма: <b>{amount} {currency_name}</b>"
    )
    await callback.message.edit_caption(
        caption=get_str(buyer_id, "pay_success", deal_id=deal_id, amount=amount, currency=currency_name, balance=buyer_data[balance_key]),
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=get_str(buyer_id, "btn_menu"), callback_data="back_to_start", style="danger", icon_custom_emoji_id="5278702045883292456")]]),
        parse_mode="HTML"
    )
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_str(seller_id, "btn_item_transferred"), callback_data=f"item_transferred_{deal_id}", style="success", icon_custom_emoji_id="5427009714745517609")],
        [InlineKeyboardButton(text=get_str(seller_id, "btn_contact_manager"), url="https://t.me/LZMarketSupport", style="danger", icon_custom_emoji_id="5467539229468793355")]
    ])
    try:
        photo = FSInputFile(IMAGE_PATH)
        await bot.send_photo(chat_id=seller_id, photo=photo,
            caption=get_str(seller_id, "seller_notif_paid", deal_id=deal_id,
                username=(callback.from_user.username if callback.from_user.username else 'N/A'),
                description=fmt_desc(deal['description']), amount=amount, currency=currency_name),
            reply_markup=keyboard, parse_mode="HTML")
    except Exception as e:
        logging.error(f"Error notifying seller of payment: {e}")


@dp.callback_query(F.data.startswith("item_transferred_"))
async def item_transferred_handler(callback: types.CallbackQuery):
    deal_id = (callback.data or "").split("_")[2]
    deal = deals_storage.get(deal_id)
    if not deal:
        await callback.answer("Сделка не найдена или уже завершена.", show_alert=True)
        return
    await callback.answer()
    seller_id = callback.from_user.id
    await send_alert(
        f"📦 <b>Продавец подтвердил передачу товара</b> #{deal_id}\n"
        f"Продавец: {_utag(callback.from_user)}\n"
        f"Сумма: <b>{deal['amount']} {deal['currency_name']}</b>"
    )
    await callback.message.edit_caption(
        caption=get_str(seller_id, "seller_text_transferred", deal_id=deal_id),
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=get_str(seller_id, "btn_start"), callback_data="back_to_start", style="danger", icon_custom_emoji_id="5278702045883292456")]]),
        parse_mode="HTML"
    )
    target_buyer = deal.get("buyer_id")
    if target_buyer:
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text=get_str(target_buyer, "btn_confirm_receipt"), callback_data=f"confirm_receipt_{deal_id}", style="success", icon_custom_emoji_id="5427009714745517609")],
            [InlineKeyboardButton(text=get_str(target_buyer, "btn_problem"), callback_data="problem_report", style="danger", icon_custom_emoji_id="5447644880824181073")]
        ])
        try:
            photo = FSInputFile(IMAGE_PATH)
            await bot.send_photo(chat_id=target_buyer, photo=photo,
                caption=get_str(target_buyer, "buyer_notif_confirm",
                    deal_id=deal_id, seller_id=deal['seller_id'],
                    description=fmt_desc(deal['description']), amount=deal['amount'], currency=deal['currency_name']),
                reply_markup=keyboard, parse_mode="HTML")
        except Exception as e:
            logging.error(f"Error notifying buyer of transfer: {e}")

@dp.callback_query(F.data.startswith("confirm_receipt_"))
async def confirm_receipt_handler(callback: types.CallbackQuery):
    deal_id = (callback.data or "").split("_")[2]
    deal = deals_storage.get(deal_id)
    if not deal:
        await callback.answer("Сделка не найдена или уже завершена.", show_alert=True)
        return
    await callback.answer()
    seller_id = deal["seller_id"]
    amount = deal["amount"]
    currency_key = deal["currency_key"]
    currency_name = deal["currency_name"]
    seller_data = get_user_requisites(seller_id)
    balance_key = f"balance_{currency_key}"
    old_balance = seller_data.get(balance_key, 0.0)
    seller_data[balance_key] += amount
    new_balance = seller_data[balance_key]
    deals_storage.pop(deal_id, None)
    global_settings["deals_completed"] = global_settings.get("deals_completed", 0) + 1
    if global_settings.get("deals_total", 0) < global_settings["deals_completed"]:
        global_settings["deals_total"] = global_settings["deals_completed"]
    save_data()
    await send_alert(
        f"✅ <b>Сделка завершена</b> #{deal_id}\n"
        f"Покупатель подтвердил получение: {_utag(callback.from_user)}\n"
        f"Продавцу (ID <code>{seller_id}</code>) зачислено: <b>+{amount} {currency_name}</b>"
    )
    finish_buyer = get_str(callback.from_user.id, "deal_completed", deal_id=deal_id, amount=amount, currency=currency_name)
    seller_finish = get_str(seller_id, "deal_completed", deal_id=deal_id, amount=amount, currency=currency_name) + \
                    get_str(seller_id, "seller_balance_update", old=old_balance, new=new_balance, currency=currency_name)
    print_console_log(f"Deal #{deal_id} completed. Seller {seller_id} +{amount} {currency_name}", "SUCCESS")
    try:
        await callback.message.edit_caption(
            caption=finish_buyer,
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=get_str(callback.from_user.id, "btn_menu"), callback_data="back_to_start", style="danger", icon_custom_emoji_id="5278702045883292456")]]),
            parse_mode="HTML"
        )
        photo = FSInputFile(IMAGE_PATH)
        await bot.send_photo(chat_id=seller_id, photo=photo, caption=seller_finish,
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=get_str(seller_id, "btn_open_menu"), callback_data="back_to_start", style="success", icon_custom_emoji_id="5278702045883292456")]]),
            parse_mode="HTML")
    except Exception as e:
        logging.error(f"Error finalizing deal: {e}")

@dp.callback_query(F.data == "problem_report")
async def problem_report_handler(callback: types.CallbackQuery):
    await callback.answer("Перенаправление в поддержку...", show_alert=True)
    await callback.message.answer("<tg-emoji emoji-id=\"5447644880824181073\">⚠️</tg-emoji> Свяжитесь с поддержкой: @LZMarketSupport", parse_mode="HTML")

@dp.callback_query(F.data == "copy_link")
async def copy_link_handler(callback: types.CallbackQuery):
    await callback.answer(get_str(callback.from_user.id, "link_copied"), show_alert=True)

@dp.callback_query(F.data == "back_to_start")
async def back_to_start_handler(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_caption(
        caption=get_str(callback.from_user.id, "main_menu_welcome"),
        reply_markup=get_main_keyboard(callback.from_user.id),
        parse_mode="HTML"
    )

# ─── Админ-панель (/admin) ──────────────────────────────────────────────────────
def _is_panel_admin(user_id) -> bool:
    return user_id in ADMIN_PANEL_IDS

def admin_panel_text() -> str:
    users = len(user_data_storage)
    active = len(deals_storage)
    completed = global_settings.get("deals_completed", 0)
    total = max(global_settings.get("deals_total", 0), completed)
    return (
        "🛠 <b>Панель управления</b>\n\n"
        f"👥 Пользователей: <b>{users}</b>\n"
        f"🎯 Активных сделок: <b>{active}</b>\n"
        f"✅ Завершённых: <b>{completed} из {total}</b>"
    )

def admin_panel_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎯 Активные сделки", callback_data="adm_deals"),
         InlineKeyboardButton(text="👥 Пользователи", callback_data="adm_users")],
        [InlineKeyboardButton(text="📌 Поиск юзера", callback_data="adm_search"),
         InlineKeyboardButton(text="📢 Рассылка", callback_data="adm_broadcast")],
        [InlineKeyboardButton(text="📊 Статистика", callback_data="adm_stats"),
         InlineKeyboardButton(text="👑 Список админов", callback_data="adm_admins")],
        [InlineKeyboardButton(text="⚙️ Настройки", callback_data="adm_settings")],
        [InlineKeyboardButton(text="🚫 Закрыть", callback_data="adm_close")],
    ])

def adm_back_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="◀️ Назад", callback_data="adm_home")]])

async def _edit_admin(callback, text, kb):
    try:
        await callback.message.edit_text(text, reply_markup=kb, parse_mode="HTML")
    except Exception:
        try:
            await callback.message.answer(text, reply_markup=kb, parse_mode="HTML")
        except Exception as e:
            logging.error(f"admin edit error: {e}")

@dp.message(Command("admin"))
async def admin_cmd(message: types.Message, state: FSMContext):
    if not _is_panel_admin(message.from_user.id):
        return
    await state.clear()
    try:
        await message.delete()
    except Exception:
        pass
    await message.answer(admin_panel_text(), reply_markup=admin_panel_kb(), parse_mode="HTML")

@dp.callback_query(F.data == "adm_home")
async def adm_home(callback: types.CallbackQuery, state: FSMContext):
    if not _is_panel_admin(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True); return
    await state.clear()
    await callback.answer()
    await _edit_admin(callback, admin_panel_text(), admin_panel_kb())

@dp.callback_query(F.data == "adm_close")
async def adm_close(callback: types.CallbackQuery, state: FSMContext):
    if not _is_panel_admin(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True); return
    await state.clear()
    await callback.answer("Закрыто")
    try:
        await callback.message.delete()
    except Exception:
        pass

@dp.callback_query(F.data == "adm_deals")
async def adm_deals(callback: types.CallbackQuery):
    if not _is_panel_admin(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True); return
    await callback.answer()
    if not deals_storage:
        text = "🎯 <b>Активные сделки</b>\n\nНет активных сделок."
    else:
        lines = ["🎯 <b>Активные сделки</b>\n"]
        for tid, d in list(deals_storage.items())[:25]:
            buyer = d.get("buyer_id", "—")
            lines.append(
                f"<b>#{tid}</b> — {d.get('amount')} {d.get('currency_name')}\n"
                f"продавец: <code>{d.get('seller_id')}</code> (@{d.get('seller_username') or '—'})\n"
                f"покупатель: <code>{buyer}</code>"
            )
        lines.append(f"\nВсего активных: {len(deals_storage)}")
        text = "\n".join(lines)
    await _edit_admin(callback, text, adm_back_kb())

@dp.callback_query(F.data == "adm_users")
async def adm_users(callback: types.CallbackQuery):
    if not _is_panel_admin(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True); return
    await callback.answer()
    ids = list(user_data_storage.keys())
    recent = ids[-15:][::-1]
    text = (
        "👥 <b>Пользователи</b>\n\n"
        f"Всего в базе: <b>{len(ids)}</b>\n"
        f"Забанено: <b>{len(banned_storage)}</b>\n\n"
        "Последние 15:\n" + "\n".join(f"<code>{i}</code>" for i in recent)
    )
    await _edit_admin(callback, text, adm_back_kb())

@dp.callback_query(F.data == "adm_stats")
async def adm_stats(callback: types.CallbackQuery):
    if not _is_panel_admin(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True); return
    await callback.answer()
    sums = {"rub": 0.0, "usd": 0.0, "ton": 0.0, "stars": 0.0}
    for u in user_data_storage.values():
        for c in sums:
            v = u.get(f"balance_{c}", 0) or 0
            if isinstance(v, (int, float)):
                sums[c] += v
    completed = global_settings.get("deals_completed", 0)
    total = max(global_settings.get("deals_total", 0), completed)
    text = (
        "📊 <b>Статистика</b>\n\n"
        f"👥 Пользователей: <b>{len(user_data_storage)}</b>\n"
        f"🚫 Забанено: <b>{len(banned_storage)}</b>\n"
        f"🎯 Активных сделок: <b>{len(deals_storage)}</b>\n"
        f"✅ Завершённых: <b>{completed} из {total}</b>\n\n"
        "<b>Сумма балансов пользователей:</b>\n"
        f"RUB: <b>{sums['rub']:.2f}</b>\n"
        f"USD: <b>{sums['usd']:.2f}</b>\n"
        f"TON: <b>{sums['ton']:.2f}</b>\n"
        f"STARS: <b>{sums['stars']:.0f}</b>"
    )
    await _edit_admin(callback, text, adm_back_kb())

@dp.callback_query(F.data == "adm_admins")
def _admins_view():
    superowners = [OWNER_ID, BAN_ADMIN_ID]
    added = global_settings.get("added_admins", [])

    text = "👑 <b>Список администраторов панели</b>\n\n"
    text += "<b>Суперовнеры (👑) — неудаляемые:</b>\n"
    for uid in superowners:
        text += f"  👑 <code>{uid}</code>\n"

    text += "\n<b>Добавленные — можно удалить:</b>\n"
    if added:
        for uid in added:
            text += f"  👤 <code>{uid}</code>\n"
    else:
        text += "  <i>нет</i>\n"

    text += "\n💡 <i>Добавленные админы получают полный доступ к панели управления.</i>"

    kb = InlineKeyboardMarkup(inline_keyboard=[])

    # Кнопки удалить для добавленных админов
    for uid in added:
        kb.inline_keyboard.append([
            InlineKeyboardButton(text=f"🚫 Удалить {uid}", callback_data=f"adm_del_admin:{uid}")
        ])

    kb.inline_keyboard.append([
        InlineKeyboardButton(text="➕ Добавить админа", callback_data="adm_add_admin")
    ])
    kb.inline_keyboard.append([
        InlineKeyboardButton(text="◀️ Назад", callback_data="adm_home")
    ])

    return text, kb

@dp.callback_query(F.data == "adm_admins")
async def adm_admins(callback: types.CallbackQuery):
    if not _is_panel_admin(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True); return
    await callback.answer()
    text, kb = _admins_view()
    await _edit_admin(callback, text, kb)

def _settings_view():
    enabled = global_settings.get("is_bot_enabled", True)
    status = "🟢 включён" if enabled else "🔴 выключен"
    ch = global_settings.get("alert_channel_id", 0) or "не подключён"
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=("🔴 Выключить бота" if enabled else "🟢 Включить бота"), callback_data="adm_toggle")],
        [InlineKeyboardButton(text="◀️ Назад", callback_data="adm_home")],
    ])
    text = (
        "⚙️ <b>Настройки</b>\n\n"
        f"Статус бота: <b>{status}</b>\n"
        f"Канал алертов: <code>{ch}</code>"
    )
    return text, kb

@dp.callback_query(F.data == "adm_settings")
async def adm_settings(callback: types.CallbackQuery):
    if not _is_panel_admin(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True); return
    await callback.answer()
    text, kb = _settings_view()
    await _edit_admin(callback, text, kb)

@dp.callback_query(F.data == "adm_toggle")
async def adm_toggle(callback: types.CallbackQuery):
    if not _is_panel_admin(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True); return
    global_settings["is_bot_enabled"] = not global_settings.get("is_bot_enabled", True)
    save_data()
    await callback.answer("Переключено")
    text, kb = _settings_view()
    await _edit_admin(callback, text, kb)

@dp.callback_query(F.data == "adm_search")
async def adm_search(callback: types.CallbackQuery, state: FSMContext):
    if not _is_panel_admin(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True); return
    await callback.answer()
    await state.set_state(AdminPanelState.waiting_search)
    await _edit_admin(callback, "📌 <b>Поиск юзера</b>\n\nОтправь <b>ID</b> пользователя (числом) или @username.", adm_back_kb())

@dp.message(AdminPanelState.waiting_search)
async def adm_search_input(message: types.Message, state: FSMContext):
    if not _is_panel_admin(message.from_user.id):
        return
    await state.clear()
    q = (message.text or "").strip()
    target = None
    if q.lstrip("-").isdigit():
        target = q
    else:
        try:
            chat = await bot.get_chat(q if q.startswith("@") else "@" + q)
            target = str(chat.id)
        except Exception:
            target = None
    try:
        await message.delete()
    except Exception:
        pass
    if not target or target not in user_data_storage:
        await message.answer(f"❌ Пользователь не найден в базе: <code>{html.escape(q)}</code>", reply_markup=adm_back_kb(), parse_mode="HTML")
        return
    u = user_data_storage[target]
    banned = "да" if target in [str(x) for x in banned_storage] else "нет"
    text = (
        f"📌 <b>Пользователь</b> <code>{target}</code>\n\n"
        f"🚫 Забанен: <b>{banned}</b>\n"
        f"🤝 Сделок (added_deals): <b>{u.get('added_deals', 0)}</b>\n"
        f"🌐 Язык: <b>{u.get('language', 'ru')}</b>\n\n"
        "<b>Балансы:</b>\n"
        f"RUB: {u.get('balance_rub', 0)} | USD: {u.get('balance_usd', 0)} | TON: {u.get('balance_ton', 0)} | STARS: {u.get('balance_stars', 0)}\n\n"
        "<b>Реквизиты:</b>\n"
        f"TON: {html.escape(str(u.get('ton', '—')))}\n"
        f"RUB: {html.escape(str(u.get('rub', '—')))}\n"
        f"USD: {html.escape(str(u.get('usd', '—')))}\n"
        f"STARS: {html.escape(str(u.get('stars', '—')))}"
    )
    await message.answer(text, reply_markup=adm_back_kb(), parse_mode="HTML")

@dp.callback_query(F.data == "adm_broadcast")
async def adm_broadcast(callback: types.CallbackQuery, state: FSMContext):
    if not _is_panel_admin(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True); return
    await callback.answer()
    await state.set_state(AdminPanelState.waiting_broadcast)
    await _edit_admin(callback, "📢 <b>Рассылка</b>\n\nОтправь текст, который разослать всем пользователям бота.", adm_back_kb())

@dp.message(AdminPanelState.waiting_broadcast)
async def adm_broadcast_input(message: types.Message, state: FSMContext):
    if not _is_panel_admin(message.from_user.id):
        return
    text = message.text or ""
    await state.update_data(bc_text=text)
    total = len(user_data_storage)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"✅ Разослать ({total})", callback_data="adm_bc_send")],
        [InlineKeyboardButton(text="◀️ Отмена", callback_data="adm_home")],
    ])
    await message.answer("📢 <b>Предпросмотр рассылки:</b>\n\n" + html.escape(text) + f"\n\n<b>Получателей:</b> {total}", reply_markup=kb, parse_mode="HTML")

@dp.callback_query(F.data == "adm_bc_send")
async def adm_bc_send(callback: types.CallbackQuery, state: FSMContext):
    if not _is_panel_admin(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True); return
    data = await state.get_data()
    text = data.get("bc_text")
    await state.clear()
    if not text:
        await callback.answer("Нет текста для рассылки", show_alert=True); return
    await callback.answer("Рассылка запущена")
    try:
        await callback.message.edit_text("📢 Рассылка запущена, ожидайте...", parse_mode="HTML")
    except Exception:
        pass
    ok = 0
    fail = 0
    for uid in list(user_data_storage.keys()):
        try:
            await bot.send_message(chat_id=int(uid), text=text)
            ok += 1
        except Exception:
            fail += 1
        await asyncio.sleep(0.05)
    await callback.message.answer(
        f"📢 <b>Рассылка завершена</b>\n\n✅ Доставлено: {ok}\n❌ Ошибок: {fail}",
        reply_markup=adm_back_kb(), parse_mode="HTML"
    )

@dp.callback_query(F.data == "adm_add_admin")
async def adm_add_admin(callback: types.CallbackQuery, state: FSMContext):
    if not _is_panel_admin(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True); return
    await callback.answer()
    await state.set_state(AdminPanelState.waiting_add_admin)
    await _edit_admin(callback, "➕ <b>Добавить админа</b>\n\nОтправь <b>ID</b> пользователя (целое число).", adm_back_kb())

@dp.message(AdminPanelState.waiting_add_admin)
async def adm_add_admin_input(message: types.Message, state: FSMContext):
    if not _is_panel_admin(message.from_user.id):
        return
    uid_str = (message.text or "").strip()
    try:
        await message.delete()
    except Exception:
        pass
    if not uid_str.lstrip("-").isdigit():
        await message.answer("❌ Некорректный ID. Отправь целое число.", parse_mode="HTML")
        return
    uid = int(uid_str)
    if uid in [8557408726, BAN_ADMIN_ID]:
        await state.clear()
        await message.answer("❌ Это суперовнер, невозможно добавить.", parse_mode="HTML")
        return
    if uid in global_settings.get("added_admins", []):
        await state.clear()
        await message.answer(f"ℹ️ Админ <code>{uid}</code> уже в списке.", reply_markup=adm_back_kb(), parse_mode="HTML")
        return
    if "added_admins" not in global_settings:
        global_settings["added_admins"] = []
    global_settings["added_admins"].append(uid)
    save_data()
    await state.clear()
    await message.answer(f"✅ Админ <code>{uid}</code> добавлен!", parse_mode="HTML")
    text, kb = _admins_view()
    await message.answer(text, reply_markup=kb, parse_mode="HTML")

@dp.callback_query(F.data.startswith("adm_del_admin:"))
async def adm_del_admin(callback: types.CallbackQuery):
    if not _is_panel_admin(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True); return
    uid_str = callback.data.split(":", 1)[1]
    try:
        uid = int(uid_str)
    except ValueError:
        await callback.answer("Ошибка", show_alert=True); return
    if "added_admins" in global_settings and uid in global_settings["added_admins"]:
        global_settings["added_admins"].remove(uid)
        save_data()
        await callback.answer(f"Админ удален")
    else:
        await callback.answer("Админ не найден", show_alert=True); return
    text, kb = _admins_view()
    await _edit_admin(callback, text, kb)

# ─── Main ──────────────────────────────────────────────────────────────────────
async def main():
    await setup_bot_commands(bot)
    print_console_log("Бот успешно запущен и готов к работе!")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
