#!/usr/bin/env python3
"""
Упрощенный запуск для хостинга
Поддерживает только cloudflare tunnel (без ngrok)
"""
import os
import sys
import time
import logging
import subprocess
from threading import Thread

# Минимальное логирование для экономии памяти
logging.basicConfig(
    level=logging.WARNING,  # Изменено с INFO на WARNING
    format='%(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def install_cloudflared():
    """Автоматическая установка cloudflared"""
    try:
        import platform
        import urllib.request
        
        system = platform.system().lower()
        machine = platform.machine().lower()
        
        # Определяем архитектуру
        if 'x86_64' in machine or 'amd64' in machine:
            arch = 'amd64'
        elif 'aarch64' in machine or 'arm64' in machine:
            arch = 'arm64'
        elif 'arm' in machine:
            arch = 'arm'
        else:
            arch = 'amd64'  # fallback
        
        # Определяем URL для скачивания
        if system == 'linux':
            url = f'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-{arch}'
            filename = 'cloudflared'
        elif system == 'windows':
            url = f'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-{arch}.exe'
            filename = 'cloudflared.exe'
        elif system == 'darwin':
            url = f'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-darwin-{arch}'
            filename = 'cloudflared'
        else:
            logger.error(f"❌ Неподдерживаемая ОС: {system}")
            return False
        
        logger.info(f"📥 Скачиваю cloudflared для {system}-{arch}...")
        logger.info(f"   URL: {url}")
        
        # Скачиваем
        urllib.request.urlretrieve(url, filename)
        
        # Даем права на выполнение (Linux/Mac)
        if system in ['linux', 'darwin']:
            os.chmod(filename, 0o755)
        
        logger.info(f"✅ cloudflared установлен: {filename}")
        return True
        
    except Exception as e:
        logger.error(f"❌ Ошибка установки cloudflared: {e}")
        return False

def start_cloudflared():
    """Запускает cloudflared tunnel (БЕЗ предупреждений!)"""
    try:
        # Проверяем наличие cloudflared
        cloudflared_cmd = None
        
        # Проверяем локальный файл
        if os.path.exists('./cloudflared'):
            cloudflared_cmd = './cloudflared'
        elif os.path.exists('./cloudflared.exe'):
            cloudflared_cmd = './cloudflared.exe'
        elif os.path.exists('cloudflared'):
            cloudflared_cmd = 'cloudflared'
        elif os.path.exists('cloudflared.exe'):
            cloudflared_cmd = 'cloudflared.exe'
        else:
            # Проверяем системный cloudflared
            try:
                subprocess.run(['cloudflared', '--version'], capture_output=True, check=True, timeout=5)
                cloudflared_cmd = 'cloudflared'
            except:
                pass
        
        # Если не найден - устанавливаем
        if not cloudflared_cmd:
            if install_cloudflared():
                if os.path.exists('./cloudflared'):
                    cloudflared_cmd = './cloudflared'
                elif os.path.exists('./cloudflared.exe'):
                    cloudflared_cmd = './cloudflared.exe'
                else:
                    return None
            else:
                return None
        
        # Логи cloudflared пишем в ФАЙЛ, а не в pipe: иначе после чтения URL
        # никто pipe не читает, буфер (64КБ) забивается, cloudflared виснет и туннель отваливается (530).
        import re
        log_path = '/tmp/cloudflared.log'
        logf = open(log_path, 'w')
        # --protocol http2: на IPv6-only хостах UDP/QUIC (порт 7844) часто зарезан,
        #                   а TCP/HTTP2 проходит. --edge-ip-version 6: ходить к edge по IPv6 (IPv4 нет).
        process = subprocess.Popen(
            [cloudflared_cmd, 'tunnel', '--protocol', 'http2', '--edge-ip-version', '6',
             '--url', 'http://localhost:5000', '--no-autoupdate'],
            stdout=logf,
            stderr=subprocess.STDOUT,  # cloudflared печатает URL в stderr — тоже в файл
        )

        # Ждем URL (макс 30 секунд), читая лог-файл
        url = None
        timeout = time.time() + 30
        while time.time() < timeout:
            time.sleep(0.5)
            try:
                with open(log_path, 'r') as f:
                    content = f.read()
            except Exception:
                content = ''
            m = re.search(r'https://[a-z0-9-]+\.trycloudflare\.com', content)
            if m:
                url = m.group(0)
                break

        if url:
            print(f"✅ Tunnel: {url}")
            return url
        else:
            return None
            
    except Exception as e:
        logger.error(f"Cloudflare error: {e}")
        return None

def start_flask(webapp_url):
    """Запускает Flask сервер (легковесный режим)"""
    os.environ['WEBAPP_URL'] = webapp_url
    
    try:
        from flask import Flask, send_from_directory
        
        app = Flask(__name__, static_folder='site')
        app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0
        
        @app.route('/')
        def index():
            return send_from_directory('site', 'index.html')
        
        @app.route('/<path:path>')
        def serve_static(path):
            return send_from_directory('site', path)
        
        # Запуск без логов для экономии памяти
        import logging as flask_logging
        flask_logging.getLogger('werkzeug').setLevel(flask_logging.ERROR)
        
        app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False, threaded=True)
        
    except Exception as e:
        logger.error(f"Flask error: {e}")

def start_bot(webapp_url):
    """Запускает Telegram бота"""
    os.environ['WEBAPP_URL'] = webapp_url
    
    try:
        subprocess.run([sys.executable, 'app.py'])
    except Exception as e:
        logger.error(f"Bot error: {e}")

def main():
    print("🎯 LZMarket Bot")
    
    # Запускаем Cloudflare Tunnel
    public_url = start_cloudflared()
    
    if not public_url:
        print("❌ Tunnel failed")
        sys.exit(1)
    
    print(f"📱 URL: {public_url}\n")
    
    # Запускаем Flask в отдельном потоке
    flask_thread = Thread(target=start_flask, args=(public_url,), daemon=True)
    flask_thread.start()
    
    # Ждем запуска Flask
    time.sleep(2)
    
    # Запускаем бота
    try:
        start_bot(public_url)
    except KeyboardInterrupt:
        sys.exit(0)
    except Exception as e:
        logger.error(f"Error: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()
